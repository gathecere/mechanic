<?php



 class Adminmodel extends CI_Model  

       {  

          function __construct()  

          {  

             // Call the Model constructor  

             parent::__construct();  

             

          }  

            public function del_order($id,$data)
            {
                $this->db->where('order_id', $id);
                $this->db->update('tbl_order',$data); 
            }

             public function del_prev($id,$data)
            {
                $this->db->where('previous_id', $id);
                $this->db->update('tbl_previous',$data); 
            }

             public function del_sample($id,$data)
            {
                $this->db->where('sample_id', $id);
                $this->db->update('tbl_sample',$data); 
            }

           public function get_current()

  {

              $this->db->select('*');

             $this->db->from('tbl_order,tbl_customer');

              $this->db->where('order_custid=cust_id');

               $this->db->where('order_statusid=5');

               $this->db->where('order_status=0');

               $this->db->order_by('posted_date',"desc");

             $query =$this->db->get();

             return $query;

                

        }


         public function get_ten_latest()

     {

              $this->db->select('*');

             $this->db->from('tbl_order,tbl_customer');

              $this->db->where('order_custid=cust_id');

              // $this->db->where('order_statusid=5');

              $this->db->where('order_status=0');

               $this->db->order_by('posted_date',"desc");

               $this->db->limit(10);


             $query =$this->db->get();

             return $query;

                

        }


         public function get_orders_now()

     {

              $this->db->select('*');

             $this->db->from('tbl_order,tbl_customer');

              $this->db->where('order_custid=cust_id');

              // $this->db->where('order_statusid=5');

              $this->db->where('order_status=0');

               $this->db->order_by('posted_date',"desc");

               //$this->db->limit(10);


             $query =$this->db->get();

             return $query;

                

        }


          public function get_current_orders()

  {

              $this->db->select('*');

             $this->db->from('tbl_order,tbl_customer');

              $this->db->where('order_custid=cust_id');

               $this->db->where('order_statusid=5');

               $this->db->where('order_status=0');

               $this->db->order_by('posted_date',"desc");

             $query =$this->db->get();

             return $query->num_rows();

                

        }





          public function get_complete()

  {

              $this->db->select('*');

             $this->db->from('tbl_order,tbl_customer');

              $this->db->where('order_custid=cust_id');

               $this->db->where('order_statusid=6');

               $this->db->where('order_status=0');

               $this->db->order_by('posted_date',"desc");

             $query =$this->db->get();

             return $query;

        }


          public function get_complete_orders()

  {

             $this->db->select('*');

             $this->db->from('tbl_order,tbl_customer');

              $this->db->where('order_custid=cust_id');

               $this->db->where('order_statusid=6');

               $this->db->where('order_status=0');

               $this->db->order_by('posted_date',"desc");

             $query =$this->db->get();

             return $query->num_rows();

        }

        

          

           public function get_orders()

          {

             

             $this->db->select('*');

             $this->db->from('tbl_order,tbl_customer');

              $this->db->where('order_custid=cust_id');

               $this->db->where('order_statusid=4');

               $this->db->where('order_status=0');

               $this->db->order_by('posted_date',"desc");

             $query =$this->db->get();

             return $query;

           

          }

           public function get_earned()

          {

             

             $this->db->select_sum('order_payeramount');

             $this->db->from('tbl_order');

             $this->db->where('order_status=0');


             $query = $this->db->get();


             return $query->row()->order_payeramount;

              

             

             //return $this->db->get()->row()->order_payeramount;


           

          }

           public function get_order_details($id)

          {

             

             $this->db->select('*');

             $this->db->from('tbl_order,tbl_customer');

             $this->db->where('order_custid=cust_id');

             $this->db->where('order_id',$id);

             $this->db->order_by('posted_date',"desc");

             $query =$this->db->get();

             return $query;

           

          }


           public function get_pending_orders()

          {

             

             $this->db->select('*');

             $this->db->from('tbl_order,tbl_customer');

             $this->db->where('order_custid=cust_id');

             $this->db->where('order_statusid=4');


             $this->db->where('order_status=0');

             $this->db->order_by('posted_date',"desc");

             $query =$this->db->get();

             return $query->num_rows();

           

          }

          

          public function login($data) {



            $condition = "admin_email =" . "'" . $data['admin_email'] . "' AND " . "admin_password =" . "'" . $data['admin_password'] . "'";

            $this->db->select('*');

            $this->db->from('tbl_admin');

            $this->db->where($condition);

            $this->db->limit(1);

            $query = $this->db->get();



            if ($query->num_rows() == 1) {

            return true;

            } else {

            return false;

            }

            }

             public function delete_previous($id)
            {

               $this->db->delete('tbl_previous', array('previous_id' => $id));  // Produces: // DELETE FROM mytable  // WHERE id = $id

            }

            public function get_acad_levels()
            {

               $this->db->select('*');

               $this->db->from('tbl_courselevel');

               $query = $this->db->get();

               return $query;

            }

             public function get_formats()
            {

               $this->db->select('*');

               $this->db->from('tbl_paperformat');

               $query = $this->db->get();

               return $query;

            }


             public function get_previous()
            {

               $this->db->select('*');

               $this->db->from('tbl_previous');

               $this->db->where('status=',0);

               $this->db->order_by('date','DESC');

               $query = $this->db->get();

               return $query;

            }

             public function get_samples()
            {

               $this->db->select('*');

               $this->db->from('tbl_sample');

               $this->db->where('status=',0);

               $this->db->order_by('sample_added','DESC');

               $query = $this->db->get();

               return $query;

            }

             public function previous_configuration()

          {

              $config = array(
                'field' => 'previous_slug',
                'title' => 'previous_title',
                'table' => 'tbl_previous',
                'id' => 'previous_id',
              );
              $this->load->library('slug', $config);

          }

             public function edit_slug($id,$title)

          {
           
           $this->previous_configuration();

            $data = array(
              'previous_title' => $title,
            );
            $data['previous_slug'] = $this->slug->create_uri($data, $id);
            $this->db->where('previous_id', $id);
            $this->db->update('tbl_previous', $data);

           

          }


             public function get_del_view()
            {

               $this->db->select('*');

               $this->db->from('tbl_previous');

               $query = $this->db->get();

               return $query;

            }

              public function get_previous_details($slug)
            {

               $this->db->select('*');

               $this->db->from('tbl_previous');

                $this->db->where('previous_slug=',$slug);

               $query = $this->db->get();

               return $query;

            }


             public function samply($slug)
            {

               $this->db->select('*');

               $this->db->from('tbl_sample');

                $this->db->where('sample_slug=',$slug);

               $query = $this->db->get();

               return $query;

            }


            

            public function read_user_information($admin_email) 

            {



                $condition = "admin_email =" . "'" . $admin_email . "'";

                $this->db->select('*');

                $this->db->from('tbl_admin');

                $this->db->where($condition);

                $this->db->limit(1);

                $query = $this->db->get();



                if ($query->num_rows() == 1) {

                return $query->result();

                } else {

                return false;

                }

            }

          

public function update($app)

          {

             

             

              

           

             

             

             // $N = count($app);

             //  for($i=0; $i < $N; $i++)

              //  {

                   $query = $this->db->query("SELECT order_statusid FROM tbl_order where order_id='$app'");



                        if ($query->num_rows() > 0)

                        {

                           $row = $query->row();



                           $status=$row->order_statusid;

                           

                                  if($status==4)

                                    {



                                      $this->db->query("UPDATE tbl_order SET order_statusid=5 WHERE order_id='$app'");



                                   }

                                

                           

                        } 

                   

                   

                  

              //  }

             

            

              

          }

          public function send($namefiles,$app)

          {

             

             

              

           

             

             

             // $N = count($app);

             //  for($i=0; $i < $N; $i++)

              //  {

                   $query = $this->db->query("SELECT order_statusid,order_complete FROM tbl_order where order_id='$app'");



                        if ($query->num_rows() > 0)

                        {

                           $row = $query->row();



                           $status=$row->order_statusid;

                           

                                  if($status==5)

                                    {



                                      $this->db->query("UPDATE tbl_order SET order_statusid=6,order_complete='$namefiles' WHERE order_id='$app'");



                                   }

                                

                           

                        } 

                   

                   

                  

              //  }

             

            

              

          }



          public function add_previous($data)
          {

             $this->db->insert('tbl_previous',$data);


          }

           public function add_sample($data)
          {

             $this->db->insert('tbl_sample',$data);


          }

          

        

           public function transaction($data,$dara)

          {

          $this->db->trans_start();



        $this->db->query('INSERT INTO tbl_customer VALUES(dara[],field1,field2)');

        $table1_id = $this->db->insert_id();



        $this->db->query('INSERT INTO tbl_order VALUES(id,' . $table1_id . ',field2,field3)');



        $this->db->trans_complete(); 

        

          } 

          

       }      