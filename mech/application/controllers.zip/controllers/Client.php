<?php

defined('BASEPATH') OR exit('No direct script access allowed');







class Client extends CI_Controller {

    

    function __construct()

	{

		parent::__construct();

		$this->load->helper('url');

                

             

                //$this->load->library("pagination");



                $this->load->database();



                // Load form helper library

                //$this->load->library('cart');



                // Load form validation library

                $this->load->library('form_validation');



                // Load session library

                $this->load->library('session');



                // Load database

                $this->load->model('Clientmodel');

                

                $this->load->helper('form');



                



	}



	/**

	 * Index Page for this controller.

	 *

	 * Maps to the following URL

	 * 		http://example.com/index.php/welcome

	 *	- or -

	 * 		http://example.com/index.php/welcome/index

	 *	- or -

	 * Since this controller is set as the default controller in

	 * config/routes.php, it's displayed at http://example.com/

	 *

	 * So any other public methods not prefixed with an underscore will

	 * map to /index.php/welcome/<method_name>

	 * @see https://codeigniter.com/user_guide/general/urls.html

	 */

    

        public function privacy()

	{

            

		$this->load->view('privacy');

                

        }

   //       public function profile()

	  // {

   //         if($this->session->userdata('logged_in')){  

		 //     $this->load->view('Client/header');

   //       }

   //       else

   //       {

   //         $this->load->view('client_login'); 

   //       }

                

   //    }

        

      public function profile()

         

	{

        $this->load->library('session');

	     if($this->session->userdata('logged_in')){  

	

	       

                  $this->session->userdata['logged_in'];

        

                $client_email = ($this->session->userdata['logged_in']['client_email']);

                 $cust_name = ($this->session->userdata['logged_in']['client_name']);

	       $this->load->database();  

            

                $this->load->model('Clientmodel');

                

                 $data['profile']=$this->Clientmodel->get_profile($client_email); 

                 $data['cust_name']= $cust_name; 



                 



            

	        	$this->load->view('Client/client_profile',$data);

          }

          else

          {

            $this->load->view('client_login');

          }

                

        }



         public function change_password()

         

      {

  

  

          $this->load->library('session');

          if($this->session->userdata('logged_in')){  

                  $this->session->userdata['logged_in'];

        

                $client_email = ($this->session->userdata['logged_in']['client_email']);

                 $cust_name = ($this->session->userdata['logged_in']['client_name']);

         $this->load->database();  

            

                $this->load->model('Clientmodel');

                

                 $data['profile']=$this->Clientmodel->get_profile($client_email); 

                 $data['cust_name']= $cust_name; 



                 



            

            $this->load->view('Client/client_change_password',$data);

             $config = array();

                $config['useragent']           = "CodeIgniter";

                $config['mailpath']            = "/usr/bin/sendmail"; // or "/usr/sbin/sendmail"

                $config['protocol']            = "smtp";

                $config['smtp_host']           = "localhost";

                $config['smtp_port']           = "25";

                $config['mailtype'] = 'html';

                $config['charset']  = 'utf-8';

                $config['newline']  = "\r\n";

                $config['wordwrap'] = TRUE;



                $this->load->library('email');



                $this->email->initialize($config);



                $this->email->from('info@writers-corp.net');

                $this->email->to($client_email);

                //$this->email->cc('xxx@gmail.com'); 

                //$this->email->bcc($this->input->post('email')); 

                $this->email->subject("WRITERS CORP PASSWORD CHANGE");

                

              //  $msg = $this->load->view('emailformat',$dasa,TRUE);

                //$msg = "Hey a new order has been received from {$name}, \n Email: {$cust_email}";



             $this->email->message(" 
                                  Hi  $cust_name,<br>
                                  Your password has been changed, your new password is:
                                  <br>
                                  $password

                                  <br>
                                  Contact us immediately if you did not initiate the process.
                                  
                                  Kind regards, <br>
                                  Writers Corp Team.

                                  ");  
            

            //echo $//this->email->print_debugger();

            //$//this->email->message($//this->load->view('email/'.$type.'-html', $data, TRUE));



                      $this->email->send();




          }

          else

          {

             $this->load->view('client_login');

          }

                

        }





        public function change_password_process()

        {

             $this->load->library('session');

           if($this->session->userdata('logged_in')){



             $client_email = ($this->session->userdata['logged_in']['client_email']);

            $cust_name = ($this->session->userdata['logged_in']['client_name']);

          

            //get the old password and check if it is correct

            $old_pass        = $this->input->post('current_password');



            $password        = $this->input->post('confirm_password');



             $cust_id        = $this->input->post('cust_id');

           // $pao=$this->hash_password($password);





            $data=array(

                  'password'=>$old_pass ,

                  'user_id'=>$cust_id,

                           );

                 

                 $this->load->database();

                 

                 $this->load->model('Clientmodel');

                 

                 $status=$this->Clientmodel->checkpasswordclient($data);





                 if($status==1)

                {

                  

                



                 $dasa=array(

               'cust_pass'=>$password,

                 );



                $this->Clientmodel->update_pass_client($cust_id,$dasa);

                $data['profile']=$this->Clientmodel->get_profile($client_email); 



                $data['sucess']="Password update successful";

                $this->load->view('Client/client_change_password', $data);

                  $config = array();

                $config['useragent']           = "CodeIgniter";

                $config['mailpath']            = "/usr/bin/sendmail"; // or "/usr/sbin/sendmail"

                $config['protocol']            = "smtp";

                $config['smtp_host']           = "localhost";

                $config['smtp_port']           = "25";

                $config['mailtype'] = 'html';

                $config['charset']  = 'utf-8';

                $config['newline']  = "\r\n";

                $config['wordwrap'] = TRUE;



                $this->load->library('email');



                $this->email->initialize($config);



                $this->email->from('info@writers-corp.net');

                $this->email->to($client_email);

                //$this->email->cc('xxx@gmail.com'); 

                //$this->email->bcc($this->input->post('email')); 

                $this->email->subject("WRITERS CORP PASSWORD CHANGE");

                

              //  $msg = $this->load->view('emailformat',$dasa,TRUE);

                //$msg = "Hey a new order has been received from {$name}, \n Email: {$cust_email}";



             $this->email->message(" 
                                  Hi  $cust_name,<br>
                                  Your password has been changed, your new password is:
                                  <br>
                                  $password

                                  <br>
                                  Contact us immediately if you did not initiate the process.
                                  
                                  Kind regards, <br>
                                  Writers Corp Team.

                                  ");  
            

            //echo $//this->email->print_debugger();

            //$//this->email->message($//this->load->view('email/'.$type.'-html', $data, TRUE));



                      $this->email->send();

                        //email to customer  

                       

                        

                        
                

           

                   

                }

                else

                {



                $data['profile']=$this->Clientmodel->get_profile($client_email); 

                $data['fail']="Wrong current password";

                $this->load->view('Client/client_change_password', $data);



          

           

          

              }

            }

           else

           {

               $this->load->view('client_login');

           }

             

            

        }



         public function edit_profile()

         

    {

    

    

            $this->load->library('session');

             if($this->session->userdata('logged_in')){



                  $this->session->userdata['logged_in'];

        

                $client_email = ($this->session->userdata['logged_in']['client_email']);

                 $cust_name = ($this->session->userdata['logged_in']['client_name']);

                $this->load->database();  

            

                $this->load->model('Clientmodel');

                //receive data

                 $cust_id=$this->input->post('cust_id');



                 $update_arr=array(

                                'cust_phone'=>$this->input->post('cust_phone'),

                                'cust_name'=>$this->input->post('cust_name'),

                                'cust_email'=>$this->input->post('cust_email'),

                                'cust_country'=>$this->input->post('cust_country'),

                    );



                 $arr=$this->Clientmodel->edit_profile($cust_id,$update_arr); 



                 //update session data

                  $this->load->library('session');

                     $session_data = array(

                    'client_name' => $arr['cust_name'],

                    'client_email' => $arr['cust_email'],

                     );

    // Add user data in session

         

                 $client_email=$arr['cust_email'];

                 $this->session->set_userdata('logged_in', $session_data);

                

                 $data['profile']=$this->Clientmodel->get_profile($client_email); 

                 $data['cust_name']= $cust_name; 



                 

                $data['message']='Profile updated successfully';

            

                $this->load->view('Client/client_profile',$data);

                  }

           else

           {

               $this->load->view('client_login');

           }

                

        }

        

        public function makeorder()

	{

	

	      

          $this->load->library('session');

             if($this->session->userdata('logged_in')){

                $client_email = ($this->session->userdata['logged_in']['client_email']);

                 $cust_name = ($this->session->userdata['logged_in']['client_name']);



	       $this->load->database();  

            

                $this->load->model('Writing_model');

                 $data['typeofpaper']=$this->Writing_model->typeofpaper(); 

                  $data['discipline']=$this->Writing_model->discipline(); 

                  $data['format']=$this->Writing_model->format(); 

                  $data['level']=$this->Writing_model->level(); 

                  

                  

                  

                    $data['hi']=$this->Writing_model->home_high_js(); 

             

              $data['undergrad_lo']=$this->Writing_model->undergrad_lower_js(); 

              $data['undergrad_hi']=$this->Writing_model->undergrad_higher_js(); 

              $data['mast']=$this->Writing_model->masters_js(); 

              $data['doct']=$this->Writing_model->doctoral_js(); 

                

                $data['high']=$this->Writing_model->home_high(); 

                $data['dropdown']=$this->Writing_model->dropdown(); 

                 $data['undergrad_lower']=$this->Writing_model->undergrad_lower(); 

                $data['undergrad_higher']=$this->Writing_model->undergrad_higher(); 

                $data['masters']=$this->Writing_model->masters(); 

                $data['doctoral']=$this->Writing_model->doctoral(); 

              

                $data['cust_name']= $cust_name; 

		           $this->load->view('Client/client_make_order',$data);

            }

           else

           {

               $this->load->view('client_login');

           }

                

        }

        

       

public function user_login_process()

{





        $data = array(

        'client_email' => $this->input->post('client_email'),

        'client_password' => $this->input->post('client_password')

       );



     $this->load->database();

     

     $this->load->model('Clientmodel');



    $result = $this->Clientmodel->login($data);



if ($result == TRUE) 

    

  {



    $client_email = $this->input->post('client_email');

    $result = $this->Clientmodel->read_user_information($client_email);

    if ($result != false) 

       {

        $cust_name='';

        $session_data = array(

        'client_name' => $result[0]->cust_name,

        'client_email' => $result[0]->cust_email,

        

         );

    // Add user data in session

          $cust_name=$result[0]->cust_name;

     $this->load->library('session');



        $this->session->set_userdata('logged_in', $session_data);

              $this->load->database();

     

               $this->load->model('Clientmodel');





              $data['check'] = $this->Clientmodel->get_myorders($client_email);

               $data['cust_name'] = $cust_name;





               

               $this->load->view('Client/client_dashboard',$data);

    }

 } 

else 

{

    

$data['error_message'] ='Invalid Username or Password';

$this->load->view('client_login', $data);

}



}



public function my_orders() {



     if($this->session->userdata('logged_in')){  



         $client_email = ($this->session->userdata['logged_in']['client_email']);

         $cust_name = ($this->session->userdata['logged_in']['client_name']);



          $this->load->database();

     

          $this->load->model('Clientmodel');





          $data['check'] = $this->Clientmodel->get_myorders($client_email);



          $data['cust_name'] = $cust_name;





               

         $this->load->view('Client/client_dashboard',$data);





     }

     else

     {

        $this->load->view('client_login');

     }







}







// Logout from admin page

public function logout() {



// Removing session data

$sess_array = array(

'client_name' => '',

'client_email' => ''

);

 $this->load->library('session');

$this->session->unset_userdata('logged_in', $sess_array);

$data['message_display'] = 'Successfully Logged out';

$this->load->view('client_login', $data);

}





        

        public function login()

	{

            

              

            

              

              

               $this->load->view('client_login');

                

    }

        

        public function process_orders_client()

	{



     if($this->session->userdata('logged_in')){  



         $client_email = ($this->session->userdata['logged_in']['client_email']);

         $cust_name = ($this->session->userdata['logged_in']['client_name']);

         

	

            if($this->input->post('submit') == "Check out with PayPal") { 

           

                 

                    

                

                 $this->load->library('upload');

            

                 if(!$this->input->post('userfiles[]'))

                   {

                       $imagename='';

                   }

                    

                   $number_of_files = sizeof($_FILES['userfile']['tmp_name']);

                   $files = $_FILES['userfile'];

                   

                   // next we pass the upload path for the images

                    $config['upload_path'] = './files/';

                    $config['allowed_types'] = 'jpg|png|pdf|doc|xml|docx';

                    $config['max_size'] = '50000';

                    $config['max_width']  = '15000';

                    $config['max_height']  = '15000';

                    

                   

                    

                   for ($i = 0; $i < $number_of_files; $i++) 

                   {

                     $_FILES['userfile']['name'] = $files['name'][$i];

                     $_FILES['userfile']['type'] = $files['type'][$i];

                     $_FILES['userfile']['tmp_name'] = $files['tmp_name'][$i];

                     $_FILES['userfile']['error'] = $files['error'][$i];

                     $_FILES['userfile']['size'] = $files['size'][$i];

                     //now we initialize the upload library

                     $this->upload->initialize($config);

                     

                     if (!$this->upload->do_upload('userfile'))

                     {

                        $error['upload_errors'][$i] = $this->upload->display_errors(); 

                        



                         //$this->load->view('submit_paid', $error);

                     }

                     

                     else

                     {

                         

                        $images = array('upload_data'=>$this->upload->data());

                        $imagename[]= $images['upload_data']['file_name'];

                        

                        

                       

                     

                     }

                  }



                      if($imagename!=NULL)

                    {

                      $namefiles= implode(',', $imagename);

                    }

                    else

                    {

                        $imagename='';

                        $namefiles=NULL;

                    }

                    

                     

                     

                    

                

                         

                         

                         

                      if($this->input->post('level')==1)

                       {

                           $amount=$this->input->post('amounthigh');

                       }

                       else if($this->input->post('level')==2)

                       {

                             $amount =$this->input->post('amountunder');

                       }

                       else if($this->input->post('level')==3)

                       {

                               $amount=$this->input->post('amountupper');

                       

                       }

                       else if($this->input->post('level')==4)

                       {

                               $amount=$this->input->post('amountmasters');

                       }

                      else if($this->input->post('level')==5)

                       {

                               $amount=$this->input->post('amountdoctoral');

                       }



                        $this->load->model('Writing_model');  

                        $customer_id=$this->Writing_model->get_customer_id($client_email);

            

           

                         

                         $data= array(

                 

                       

                                           

                        'order_levelid' => $this->input->post('level'),

                        'order_essaytypeid' => $this->input->post('typeofpaper'),

                        'order_disciplineid' => $this->input->post('discipline'),

                        'order_topic' => $this->input->post('topic'),

                        'order_instructions' => $this->input->post('instructions'),

                        'order_files' => $namefiles,

                        'order_sources' => $this->input->post('sources'),

                        'order_formatid' => $this->input->post('format'),

                        'order_custid' => $customer_id,

                        'order_deadlineid' => 1,

                        'order_price' => $amount,

                        'order_paymentstatus'=>"Pending",

                        'order_statusid'=>4,

                        'order_pages'=>$this->input->post('orderpages'),

                        



                        );

                        

                        

                        $this->load->model('Writing_model');  

                        $orderid=$this->Writing_model->process_orders($data);

                         $cust_email = $this->input->post('email');

                          $this->load->model('Writing_model');

                        $dasa['g']=$this->Writing_model->client_name($cust_email,$orderid);

                        

                        

                       

                        $name= $this->input->post('name');

                       

                       $order_topic = $this->input->post('topic');        

                         

                        // $data['notification']="Congratulations your order has been received successfully";

                         //$//this->load->view('order_now', $data);

                   $this->load->library('paypal_lib');      

                         

       // $paypalURL = 'https://www.sandbox.paypal.com/cgi-bin/webscr'; //test PayPal api url

        //$paypalID = 'weka@gmail.com'; //business email

        $returnURL = base_url().'paypal/success'; //payment success url

        $cancelURL = base_url().'paypal/cancel'; //payment cancel url

        $notifyURL = base_url().'paypal/success'; //ipn url

        //get particular product data

       // $product = $//this->product->getRows($id);

        $userID = 1; //current user id

        $logo = base_url().'assets/images/codexworld-logo.png';

        

        //$this->paypal_lib->add_field('business', $paypalID);

        $this->paypal_lib->add_field('return', $returnURL);

        $this->paypal_lib->add_field('cancel_return', $cancelURL);

        $this->paypal_lib->add_field('notify_url', $notifyURL);

        $this->paypal_lib->add_field('item_name', 'YO Sthg');

        //$this->paypal_lib->add_field('custom',  $orderid);

        $this->paypal_lib->add_field('item_number',  $orderid);

        $this->paypal_lib->add_field('amount',   $amount);        

        $this->paypal_lib->image($logo);

        

        $this->paypal_lib->paypal_auto_form();
        
                 $this->load->library('session');

          
        

                $client_email = ($this->session->userdata['logged_in']['client_email']);

                 $cust_name = ($this->session->userdata['logged_in']['client_name']);


               $cust_email = $client_email;
                $name=  $cust_name;

               //email to admin

               $config = array();

                $config['useragent']           = "CodeIgniter";

                $config['mailpath']            = "/usr/bin/sendmail"; // or "/usr/sbin/sendmail"

                $config['protocol']            = "smtp";

                $config['smtp_host']           = "localhost";

                $config['smtp_port']           = "25";

                $config['mailtype'] = 'html';

                $config['charset']  = 'utf-8';

                $config['newline']  = "\r\n";

                $config['wordwrap'] = TRUE;



                $this->load->library('email');



                $this->email->initialize($config);



                $this->email->from('info@writers-corp.net'); 

                $this->email->to($cust_email);

                $this->email->bcc('henrykuto@gmail.com'); 

                //$this->email->bcc($this->input->post('email')); 

                $this->email->subject("WRITERS CORP ORDER: {$orderid}");

                

              //  $msg = $this->load->view('emailformat',$dasa,TRUE);

                //$msg = "Hey a new order has been received from {$name}, \n Email: {$cust_email}";



             $this->email->message(" 
             	                    Dear  $name,<br>
             	                    We have received your order, you can view your order details on the client dashboard.
             	                    <br>
             	                    For any queries reach us on support@writers-corp.net or use our live chat on the website.

             	                    <br>
             	                    Kind regards, <br>
             	                    Writers Corp Team.

                                  ");  
            

            //echo $//this->email->print_debugger();

            //$//this->email->message($//this->load->view('email/'.$type.'-html', $data, TRUE));



            $this->email->send();



                        

                        

                        

                         

                         

                         

                       

                         

        

           

          }

       else {   

        //card payment starts here

        // include_once('../top.php');

  // require_once('OAuth.php');

  //       require_once('checkStatus.php');

  // //require_once('../db/dbconnector.php');

  // $this->load->library('form_validation');



  

                         

              



  

  //          $this->form_validation->set_rules('email', 'Email', 'is_unique[tbl_customer.cust_email]');

           

  //           if ($this->form_validation->run() == FALSE)

  //                   {



  //                      $data['messo']="Email already in use, login below";

  //                      $this->load->view('Client/login',$data);

  //                   } 

                 

                    

  //               else 

  //                   {



  //           $this->load->library('upload');

            

  //                if(!$this->input->post('userfiles[]'))

  //                  {

  //                      $imagename='';

  //                  }

                    

  //                  $number_of_files = sizeof($_FILES['userfile']['tmp_name']);

  //                  $files = $_FILES['userfile'];

                   

  //                  // next we pass the upload path for the images

  //                  $config['upload_path'] = './files/';

  //                   $config['allowed_types'] = 'jpg|png|pdf|doc|xml|docx';

  //                   $config['max_size'] = '5000';

  //                   $config['max_width']  = '1500';

  //                   $config['max_height']  = '1500';

                    

                   

                    

  //                  for ($i = 0; $i < $number_of_files; $i++) 

  //                  {

  //                    $_FILES['userfile']['name'] = $files['name'][$i];

  //                    $_FILES['userfile']['type'] = $files['type'][$i];

  //                    $_FILES['userfile']['tmp_name'] = $files['tmp_name'][$i];

  //                    $_FILES['userfile']['error'] = $files['error'][$i];

  //                    $_FILES['userfile']['size'] = $files['size'][$i];

  //                    //now we initialize the upload library

  //                    $this->upload->initialize($config);

                     

  //                    if (!$this->upload->do_upload('userfile'))

  //                    {

  //                       $error['upload_errors'][$i] = $this->upload->display_errors(); 

                        



  //                        //$this->load->view('submit_paid', $error);

  //                    }

                     

  //                    else

  //                    {

                         

  //                       $images = array('upload_data'=>$this->upload->data());

  //                       $imagename[]= $images['upload_data']['file_name'];

                        

                        

                       

                     

  //                    }

  //                 }

  //                     if($imagename!=NULL)

  //                   {

  //                     $namefiles= implode(',', $imagename);

  //                   }

  //                   else

  //                   {

  //                       $imagename='';

  //                       $namefiles=NULL;

  //                   }

                    

                     

                     

                    

  //                 $dara= array(

                 

                       

                                           

  //                         'cust_email' => $this->input->post('email'),

                           

  //                       'cust_pass' => $this->input->post('password'),

  //                       'cust_name' => $this->input->post('name'),

  //                        'cust_country' => $this->input->post('country'),

  //                        'cust_phone' => $this->input->post('phone'),

                         

                        



  //                       );

                        

                        

                        

  //                        $this->load->model('Writingmodel');  



  //                        $tableid=$this->Writingmodel->customer_details($dara);

                         

                         

                         

  //                        if($this->input->post('level')==1)

  //                    {

  //                        $amount=$this->input->post('amounthigh');

  //                    }

  //                    else if($this->input->post('level')==2)

  //                    {

  //                          $amount =$this->input->post('amountunder');

  //                    }

  //                    else if($this->input->post('level')==3)

  //                    {

  //                            $amount=$this->input->post('amountupper');

                     

  //                    }

  //                    else if($this->input->post('level')==4)

  //                    {

  //                            $amount=$this->input->post('amountmasters');

  //                    }

  //                   else if($this->input->post('level')==5)

  //                    {

  //                            $amount=$this->input->post('amountdoctoral');

  //                    }

            

           

                         

  //                        $data= array(

                 

                       

                                           

  //                         'order_levelid' => $this->input->post('level'),

  //                       'order_essaytypeid' => $this->input->post('typeofpaper'),

  //                       'order_disciplineid' => $this->input->post('discipline'),

  //                        'order_topic' => $this->input->post('topic'),

  //                        'order_instructions' => $this->input->post('instructions'),

  //                        'order_files' => $namefiles,

  //                        'order_sources' => $this->input->post('sources'),

  //                          'order_formatid' => $this->input->post('format'),

  //                           'order_custid' => $tableid,

  //                           'order_deadlineid' => 1,

  //                            'order_price' => $amount,

  //                            'order_paymentstatus'=>"Pending",

  //                              'order_statusid'=>4,

  //                               'order_pages'=>$this->input->post('orderpages'),

                        



  //                       );

                        

                        

  //                       $this->load->model('Writingmodel');  

  //                       $orderid=$this->Writingmodel->process_orders($data);

  //                         $cust_email = $this->input->post('email');

                        

  //                       $this->load->model('Writingmodel');  

                        

  //                         $dasa['g']=$this->Writingmodel->client_name($cust_email,$orderid);

                        

                        

                         

                         

                         

                         

                          

            

            

           

                        

                        

  

  //   //$api = 'https://www.pesapal.com';

  

  // $token = $params  = NULL;

  // $iframelink     = 'https://demo.pesapal.com/api/PostPesapalDirectOrderV4';

  

  // //Kenyan keys

  // $consumer_key     = "LBS6DCgQK8AQ1ClN4/qLRF2/P6YI/65o"; 

  // $consumer_secret  = "VY/urpjSz/yPiX3q/OqKcet6MYk=";

   

  // $signature_method = new OAuthSignatureMethod_HMAC_SHA1();

  // $consumer       = new OAuthConsumer($consumer_key, $consumer_secret);

  

  

  

  // //get form details

  

  //   $ref        =  str_repeat('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',5);

  //   $_POST['reference'] =  substr(str_shuffle($ref),0,10);

  

  

  // //$amount     = str_replace(',','',$_POST['amount']); // remove thousands seperator if included

  // $amount     = number_format($amount, 2); //format amount to 2 decimal places

  // $desc       = $this->input->post('description');

  // $type       = 'MERCHANT'; 

  // $first_name   = $this->input->post('name');

  // //$last_name    = $_POST['last_name'];

  // $email      =$this->input->post('email');

  // $phonenumber  = $this->input->post('phone');

  // $currency     = $this->input->post('currency');

  // $reference    = $orderid;//unique transaction id, generated by merchant.

  // $callback_url   = 'customwritingshub.com/writing/pesapalipn'; //URL user to be redirected to after payment

  

  // //Record order in your database.

  // //$database = new pesapalDatabase();

  // //$database->store($_POST); 

    

  // $post_xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?>

  //          <PesapalDirectOrderInfo 

  //           xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" 

  //             xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" 

  //             Currency=\"".$currency."\" 

  //             Amount=\"".$amount."\" 

  //             Description=\"".$desc."\" 

  //             Type=\"".$type."\" 

  //             Reference=\"".$reference."\" 

  //             FirstName=\"".$first_name."\" 

              

  //             Email=\"".$email."\" 

  //             PhoneNumber=\"".$phonenumber."\" 

  //             xmlns=\"http://www.pesapal.com\" />";

  // $post_xml = htmlentities($post_xml);

  

  // //post transaction to pesapal

  // $iframe_src = OAuthRequest::from_consumer_and_token($consumer, $token, "GET", $iframelink, $params);

  // $iframe_src->set_parameter("oauth_callback", $callback_url);

  // $iframe_src->set_parameter("pesapal_request_data", $post_xml);

  // $iframe_src->sign_request($signature_method, $consumer, $token);  ?>

  

  // <iframe src="<?php echo $iframe_src;?>" width="100%" height="700px"  scrolling="no" frameBorder="0">

  //         <p>Browser unable to load iFrame</p>

  //       </iframe>

        

  //      <?php 

       

       

       

  //      $cust_email = $this->input->post('email');

  //                       $name= $this->input->post('name');

                        

  //                       $config = array();

  //               $config['useragent']           = "CodeIgniter";

  //               $config['mailpath']            = "/usr/bin/sendmail"; // or "/usr/sbin/sendmail"

  //               $config['protocol']            = "smtp";

  //               $config['smtp_host']           = "localhost";

  //               $config['smtp_port']           = "25";

  //               $config['mailtype'] = 'html';

  //               $config['charset']  = 'utf-8';

  //               $config['newline']  = "\r\n";

  //               $config['wordwrap'] = TRUE;



  //               $this->load->library('email');



  //               $this->email->initialize($config);



  //               $this->email->from('info@customwritingshub.com');

  //               $this->email->to('customwritingshub@gmail.com');

  //               //$this->email->cc('xxx@gmail.com'); 

  //               //$this->email->bcc($this->input->post('email')); 

  //              $this->email->subject("ORDER: {$orderid}");

  //              $mseg= $this->load->view('emailformat',$dasa,TRUE);



  //           $this->email->message($mseg);   

            

  //           //echo $//this->email->print_debugger();

  //           //$//this->email->message($//this->load->view('email/'.$type.'-html', $data, TRUE));



  //           $this->email->send();



                        

                        

                        

                         

                         

                         

                          

  //                       $cust_email = $this->input->post('email');

  //                       $name= $this->input->post('name');

                        

  //                       $config = array();

  //               $config['useragent']           = "CodeIgniter";

  //               $config['mailpath']            = "/usr/bin/sendmail"; // or "/usr/sbin/sendmail"

  //               $config['protocol']            = "smtp";

  //               $config['smtp_host']           = "localhost";

  //               $config['smtp_port']           = "25";

  //               $config['mailtype'] = 'html';

  //               $config['charset']  = 'utf-8';

  //               $config['newline']  = "\r\n";

  //               $config['wordwrap'] = TRUE;



  //               $this->load->library('email');



  //               $this->email->initialize($config);



  //               $this->email->from('info@customwritingshub.com');

  //               $this->email->to($cust_email);

  //               //$this->email->cc('xxx@gmail.com'); 

  //               //$this->email->bcc($this->input->post('email')); 

  //              $this->email->subject("ORDER: {$orderid}");

  //               $msg= $this->load->view('clientformat',$dasa,TRUE);



  //           $this->email->message($msg);   

            

  //           //echo $//this->email->print_debugger();

  //           //$//this->email->message($//this->load->view('email/'.$type.'-html', $data, TRUE));



  //           $this->email->send();













     

            }   

          

        }

     else

     {

        $this->load->view('client_login');

     }

     }   

        

}