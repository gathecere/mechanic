<?php

defined('BASEPATH') OR exit('No direct script access allowed');







class Admin extends CI_Controller {

    

    function __construct()

	{

		parent::__construct();

		$this->load->helper('url');

                

             

                //$this->load->library("pagination");



                $this->load->database();



                // Load form helper library

                //$this->load->library('cart');



                // Load form validation library

                $this->load->library('form_validation');



                // Load session library

                $this->load->library('session');



                // Load database

                $this->load->model('Adminmodel');



                



	}



	/**

	 * Index Page for this controller.

	 *

	 * Maps to the following URL

	 * 		http://example.com/index.php/welcome

	 *	- or -

	 * 		http://example.com/index.php/welcome/index

	 *	- or -

	 * Since this controller is set as the default controller in

	 * config/routes.php, it's displayed at http://example.com/

	 *

	 * So any other public methods not prefixed with an underscore will

	 * map to /index.php/welcome/<method_name>

	 * @see https://codeigniter.com/user_guide/general/urls.html

	 */

    

        public function auth()

	{

		$this->get_orders();

                

        }



     public function index()

	{

		  $this->load->view('admin_login');

                

    }

        

         public function login()

	{

		  $this->load->view('admin_login');

                

    }

     public function delete_view()

  {

            $this->load->database();  

            

               $this->load->model('Adminmodel');

               //$data = array();

               $data['del']=$this->Adminmodel->get_del_view(); 

              

               $this->load->view('Admin/del_view',$data);

    }

     public function delete_entry()
  {
   
     $id=$this->uri->segment(3);
     
   
    

     $this->load->database();

     $this->load->model('Adminmodel');

     $arr=array(
                  'order_status'=>1,
               );



     $this->Adminmodel->del_order($id,$arr);




     //unlink(FCPATH.'video/'.$name);

     // $ifile="/cms/video".$name;
     // unlink($_SERVER['DOCUMENT_ROOT'] .$ifile);

     $data['all']=$this->Adminmodel->get_orders_now(); 

     $data['success']="Entry deleted successfully";

   

     $this->load->view('Admin/all_orders',$data);

  }


   public function delete_entry_previous()
  {
   
     $id=$this->uri->segment(3);
     
   
    

     $this->load->database();

     $this->load->model('Adminmodel');

     $arr=array(
                  'status'=>1,
               );



     $this->Adminmodel->del_prev($id,$arr);




     //unlink(FCPATH.'video/'.$name);

     // $ifile="/cms/video".$name;
     // unlink($_SERVER['DOCUMENT_ROOT'] .$ifile);

      $data['h']=$this->Adminmodel->get_previous(); 

     $data['success']="Entry deleted successfully";

   

     $this->load->view('Admin/del_previous',$data);

  }

   public function get_previous_papers()
  {
   
    
     
   
    

     $this->load->database();

     $this->load->model('Adminmodel');


     $data['h']=$this->Adminmodel->get_previous(); 

    // $data['success']="Entry deleted successfully";

   

     $this->load->view('Admin/del_previous',$data);

  }


    public function update_previous_slug()
  {
   
    
     
   
    

     $this->load->database();

     $this->load->model('Adminmodel');


     $datay=$this->Adminmodel->get_previous(); 

     foreach ($datay->result() as $row) {

         $title=$row->previous_title;
         $id=$row->previous_id;

         $this->Adminmodel->edit_slug($id,$title);
       # code...
     }

    // $data['success']="Entry deleted successfully";

   

    // $this->load->view('Admin/del_previous',$data);

  }



    public function get_samples()
  {
   
    
     
   
    

     $this->load->database();

     $this->load->model('Adminmodel');


     $data['h']=$this->Adminmodel->get_samples(); 

     //$data['success']="Entry deleted successfully";

   

     $this->load->view('Admin/sample_view',$data);

  }

   public function delete_sample()
  {
   
     $id=$this->uri->segment(3);
     
   
    

     $this->load->database();

     $this->load->model('Adminmodel');

     $arr=array(
                  'status'=>1,
               );



     $this->Adminmodel->del_sample($id,$arr);




     //unlink(FCPATH.'video/'.$name);

     // $ifile="/cms/video".$name;
     // unlink($_SERVER['DOCUMENT_ROOT'] .$ifile);

      $data['h']=$this->Adminmodel->get_samples(); 

     $data['success']="Entry deleted successfully";

   

     $this->load->view('Admin/sample_view',$data);

  }
                


        

         public function get_current()

	{

	           	$this->load->database();  
 
            

               $this->load->model('Adminmodel');

               //$data = array();

               $data['current']=$this->Adminmodel->get_current(); 

              

               $this->load->view('Admin/current',$data);

                

        }

           public function add_previous()

        {

               $this->load->view('Admin/add_previous');


        }


         public function add_sample()

        {

               $this->load->database();  
 
            

               $this->load->model('Adminmodel');

               //$data = array();

               $data['academic_level']=$this->Adminmodel->get_acad_levels(); 

               $data['style']=$this->Adminmodel->get_formats(); 



               $this->load->view('Admin/add_sample',$data);


        }

         public function previous_configuration()

          {

              $config = array(
                'field' => 'previous_slug',
                'title' => 'previous_title',
                'table' => 'tbl_previous',
                'id' => 'previous_id',
              );
              $this->load->library('slug', $config);

          }

          public function add_previous_process()

        {

                 $title=$this->input->post('title');  
                 $description=$this->input->post('description');  
                 $keywords=$this->input->post('keywords'); 
                  $paper=$this->input->post('paper');  

                 $insertion=array(
                                  'previous_title' => $title, 
                                  'previous_description' => $description, 
                                  'previous_keywords' => $keywords, 
                                  'previous_paper' => $paper, 



                                  );


            

             $this->load->model('Adminmodel');

               //$data = array();
             $this->previous_configuration();

             $insertion['previous_slug'] = $this->slug->create_uri($insertion);

             $this->Adminmodel->add_previous($insertion); 

             $data['success']="Record added successfully";


              

               $this->load->view('Admin/add_previous',$data);

                

        }

         public function sample_configuration()

          {

              $config = array(
                'field' => 'sample_slug',
                'title' => 'sample_title',
                'table' => 'tbl_sample',
                'id' => 'sample_id',
              );
              $this->load->library('slug', $config);

          }


         public function add_sample_process()

        {

                 
             

                    //start of upload class

                    $config['upload_path']          = './sample/';

                    $config['allowed_types'] = 'jpg|png|pdf|doc|xml|docx';

                    $config['max_size'] = '50000';

                    $config['max_width']  = '1500';

                    $config['max_height']  = '1500';

    

                    $this->load->library('upload', $config);

    

                    if (! $this->upload->do_upload('userfile'))

                    {

                            $error = array('error' => $this->upload->display_errors());



                            // $this->session->set_flashdata('error',$error['error']);

                           $data['error']=$error['error'];

                           $data['academic_level']=$this->Adminmodel->get_acad_levels(); 

                           $data['style']=$this->Adminmodel->get_formats(); 

    

                          //  $data['h']=$this->Bulksmsmodel->get_specific_ad($id);  

                            $this->load->view('Admin/add_sample', $data);

                    }
                    else
                    {

                    $upload_data = $this->upload->data(); 

                    $file_name =   $upload_data['file_name'];



                 

                 $sample_title=$this->input->post('sample_title');  
                 $sample_paragraph=$this->input->post('sample_paragraph');  
                 $sample_paper=$this->input->post('sample_paper'); 
                 $sample_pages=$this->input->post('sample_pages'); 
                 $sample_subject_area=$this->input->post('sample_subject_area'); 
                 $sample_academic_level=$this->input->post('sample_academic_level'); 
                 $sample_number_sources=$this->input->post('sample_number_sources'); 
                 $sample_urgency=$this->input->post('sample_urgency');
                 $sample_price=$this->input->post('sample_price'); 
                 $sample_style=$this->input->post('sample_style'); 
                // $sample_urgency=$this->input->post('sample_urgency');   

                 $insertion=array(
                                  'sample_title' => $sample_title, 
                                  'sample_paragraph' => $sample_paragraph, 
                                  'sample_paper' => $sample_paper, 
                                  'sample_pages' => $sample_pages, 
                                  'sample_subject_area' => $sample_subject_area, 
                                  'sample_academic_level' => $sample_academic_level, 
                                  'sample_number_sources' => $sample_number_sources, 
                                  'sample_urgency' => $sample_urgency, 
                                  'sample_price' => $sample_price, 
                                  'sample_style' => $sample_style, 
                                  'sample_upload' => $file_name, 


                                  );


            

             $this->load->model('Adminmodel');

             $this->sample_configuration();

             $insertion['sample_slug'] = $this->slug->create_uri($insertion);

               //$data = array();

             $this->Adminmodel->add_sample($insertion); 

             $data['success']="Record added successfully";

             $data['academic_level']=$this->Adminmodel->get_acad_levels(); 

             $data['style']=$this->Adminmodel->get_formats(); 


              

              $this->load->view('Admin/add_sample',$data);


             }
            
                

        }

         public function order_details()

        {


            
             $id= $this->uri->segment(3);
             $this->load->model('Adminmodel');

               //$data = array();

            
              $data['h']=$this->Adminmodel->get_order_details($id); 
           

            


              

               $this->load->view('Admin/order_details',$data);

                

        }


        public function admin_dashboard()

        {


            
             $id= $this->uri->segment(3);
             $this->load->model('Adminmodel');

               //$data = array();

             $data['pending']=$this->Adminmodel->get_pending_orders(); 
             $data['current']=$this->Adminmodel->get_current_orders(); 
             $data['complete']=$this->Adminmodel->get_complete_orders(); 
             $data['earned']=$this->Adminmodel->get_earned(); 

              $data['h']=$this->Adminmodel->get_ten_latest(); 
           

            


              

               $this->load->view('Admin/admin_dashboard',$data);

                

        }

         public function req()
    {

       $this->load->database();

        $this->load->model('Writing_model');

       

        

       

        $data['samples']=$this->Writing_model->get_samples(); 
        // $data['typeofpaper']=$this->Writing_model->typeofpaper(); 

      $data['discipline']=$this->Writing_model->discipline(); 

      $data['format']=$this->Writing_model->format(); 

      $data['level']=$this->Writing_model->level(); 

       $data['deadline']=$this->Writing_model->deadline(); 


       return $data;



    }


            public function get_prev()

        {


            
             $slug= $this->uri->segment(3);
             $this->load->model('Adminmodel');

               //$data = array();

             $lynn=$this->Adminmodel->get_previous_details($slug); 
             $result=$lynn->result();
             $title=$result[0]->previous_title;
             $keywords=$result[0]->previous_keywords;
             $description=$result[0]->previous_description;
             $paper=$result[0]->previous_paper;


           $this->load->model('Writing_model');

       

        

       

        $data['samples']=$this->Writing_model->get_samples(); 
        // $data['typeofpaper']=$this->Writing_model->typeofpaper(); 

      $data['discipline']=$this->Writing_model->discipline(); 

      $data['format']=$this->Writing_model->format(); 

      $data['level']=$this->Writing_model->level(); 

       $data['deadline']=$this->Writing_model->deadline(); 


           $data['title']= $title;

           $data['description']=$description;

           $data['keywords']=$keywords;

           $data['paper']= $paper;
           $data['title']= $title;


          
            

            


              

               $this->load->view('get_previous_details',$data);

                

        }


         public function get_sample()

        {


            
             $slug= $this->uri->segment(3);
             $this->load->model('Adminmodel');

               //$data = array();

             $lynn=$this->Adminmodel->samply($slug); 
             $result=$lynn->result();
             $title=$result[0]->sample_title;
             $keywords=$result[0]->sample_subject_area;
             $description=$result[0]->sample_paragraph;
             $paper=$result[0]->sample_paper;

             $this->load->model('Writing_model');


              $data['samples']=$this->Writing_model->get_samples(); 
        // $data['typeofpaper']=$this->Writing_model->typeofpaper(); 

      $data['discipline']=$this->Writing_model->discipline(); 

      $data['format']=$this->Writing_model->format(); 

      $data['level']=$this->Writing_model->level(); 

       $data['deadline']=$this->Writing_model->deadline(); 


           $data['title']= $title;

           $data['description']=$description;

           $data['keywords']=$keywords;

           $data['paper']= $paper;
           $data['title']= $title;
            

            
              // $this->req();

              

               $this->load->view('get_previous_details',$data);

                

        }
        
        public function get_previous_work()
        {


            

             $this->load->model('Adminmodel');

               //$data = array();

             $data['h']=$this->Adminmodel->get_previous(); 

            


              

               $this->load->view('get_previous',$data);

                

        }

         public function get_complete()

	    {

		      $this->load->database();  

            

               $this->load->model('Adminmodel');

               //$data = array();

               $data['complete']=$this->Adminmodel->get_complete(); 

              

               $this->load->view('Admin/complete',$data);

                

        }

         public function get_orders_now()

      {

               $this->load->database();  

            

               $this->load->model('Adminmodel');

               //$data = array();

               $data['all']=$this->Adminmodel->get_orders_now(); 

              

               $this->load->view('Admin/all_orders',$data);

                

        }

         public function pending()

     	{


		          $this->get_orders();  

            

                

        }

         public function update()

	{

             $this->load->database();  

             //load the model  

             $this->load->model('Adminmodel');  

             

             $app =  $this->uri->segment(3);

             

             //load the method of model  

             $data['h']=$this->Adminmodel->update($app);  

             //return the data in view  

              $this->pending();

             

             //$this->load->view('admin_panel', $data);

	}

	

	 public function send()

	{

	

	        $this->load->library('upload');

            

                 if(!$this->input->post('userfiles[]'))

                   {

                       $imagename='';

                   }

                    

                   $number_of_files = sizeof($_FILES['userfile']['tmp_name']);

                   $files = $_FILES['userfile'];

                   

                   // next we pass the upload path for the images

                   $config['upload_path'] = './complete/';

                    $config['allowed_types'] = 'jpg|png|pdf|doc|xml|docx';

                    $config['max_size']	= '50000';

                    $config['max_width']  = '1500';

                    $config['max_height']  = '1500';

                    

                   

                    

                   for ($i = 0; $i < $number_of_files; $i++) 

                   {

                     $_FILES['userfile']['name'] = $files['name'][$i];

                     $_FILES['userfile']['type'] = $files['type'][$i];

                     $_FILES['userfile']['tmp_name'] = $files['tmp_name'][$i];

                     $_FILES['userfile']['error'] = $files['error'][$i];

                     $_FILES['userfile']['size'] = $files['size'][$i];

                     //now we initialize the upload library

                     $this->upload->initialize($config);

                     

                     if (!$this->upload->do_upload('userfile'))

                     {

                        $error['upload_errors'][$i] = $this->upload->display_errors(); 

                        



                         //$this->load->view('submit_paid', $error);

                     }

                     

                     else

                     {

                         

                        $images = array('upload_data'=>$this->upload->data());

                        $imagename[]= $images['upload_data']['file_name'];

                        

                        

                       

                     

                     }

                  }

                      if($imagename!=NULL)

                    {

                      $namefiles= implode(',', $imagename);

                    }

                    else

                    {

                        $imagename='';

                        $namefiles=NULL;

                    }

            

                    

            

            

             $this->load->database();  

             //load the model  

             $this->load->model('Adminmodel');  

             

             $app =  $this->input->post('order_id');

             

             //load the method of model  

             $data['h']=$this->Adminmodel->send($namefiles,$app);  

              $email =  $this->input->post('email');

              //$this->load->helper('path'); 

             //$path = set_realpath('complete/');  

             $this->load->helper('directory'); 

              $direct='/complete'; 

            

           

                        

                        $config = array();

                $config['useragent']           = "CodeIgniter";

                $config['mailpath']            = "/usr/bin/sendmail"; // or "/usr/sbin/sendmail"

                $config['protocol']            = "smtp";

                $config['smtp_host']           = "localhost";

                $config['smtp_port']           = "25";

                $config['mailtype'] = 'html';

                $config['charset']  = 'utf-8';

                $config['newline']  = "\r\n";

                $config['wordwrap'] = TRUE;



                $this->load->library('email');



                $this->email->initialize($config);



                $this->email->from('info@writers-corp.net');

                $this->email->to($email);

               // $this->email->cc('xxx@gmail.com'); 

                //$this->email->bcc($this->input->post('email')); 

                $this->email->subject('Dear client your order has been completed');

                $mseg = "Dear client , \n  Your order has been completed. \n  Thank you for choosing Writers Corp. <br>
                   Kind regards, <br>
                   Writers Corp.

                ";

                

                 



            $this->email->message($mseg);   

             $attched_file= $_SERVER["DOCUMENT_ROOT"]."/complete/".$namefiles;

            $this->email->attach($attched_file);

           // $this->email->attach('base_url($direct)."/".$namefiles;');  

            

            //echo $//this->email->print_debugger();

            //$//this->email->message($//this->load->view('email/'.$type.'-html', $data, TRUE));



            $this->email->send();

             //return the data in view  

              $this->get_current();

             

             //$this->load->view('admin_panel', $data);

	}

        public function get_orders()

	{

            

               $this->load->database();  

            

               $this->load->model('Adminmodel');

               //$data = array();

               $data['orders']=$this->Adminmodel->get_orders(); 

              

               $this->load->view('Admin/pending_orders',$data);

                

        }

         public function user_login_process()

{



$this->load->library('form_validation');



$this->form_validation->set_rules('admin_email', 'Email', 'trim|required');

$this->form_validation->set_rules('admin_password', 'Password', 'trim|required');



  if ($this->form_validation->run() == FALSE) 

    {

    

       if(isset($this->session->userdata['loggged_in']))

           

         {

    

              $this->get_orders();

     

         }

     else

      {

     

             $this->load->view('admin_login');

      

      }

   } 

else 

   {

        $data = array(

        'admin_email' => $this->input->post('admin_email'),

        'admin_password' => $this->input->post('admin_password')

);



     $this->load->database();

     

     $this->load->model('Adminmodel');



    $result = $this->Adminmodel->login($data);



if ($result == TRUE) 

    

  {



    $admin_email = $this->input->post('admin_email');

    $result = $this->Adminmodel->read_user_information($admin_email);

    if ($result != false) 

       {

        $session_data = array(

        'admin_name' => $result[0]->admin_name,

        'admin_email' => $result[0]->admin_email,

         );

    // Add user data in session

     $this->load->library('session');



        $this->session->set_userdata('loggged_in', $session_data);

                 $this->load->database();

     

               $this->admin_dashboard();
    }

 } 

else 

{

    

$data['error_message'] ='Invalid Username or Password';

$this->load->view('admin_login', $data);

    }

}

}



// Logout from admin page

public function logout() {



// Removing session data

$sess_array = array(

'admin_name' => ''

);

 $this->load->library('session');

$this->session->unset_userdata('loggged_in', $sess_array);

$data['message_display'] = 'Successfully Logout';

$this->load->view('admin_login', $data);

}





        

       

        

}