<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Paypal extends CI_Controller 
{
     function  __construct(){
        parent::__construct();
        $this->load->library('Paypal_lib');
        $this->load->database();
        $this->load->model('Writing_model');
     }
     
     function success(){
        //get the transaction data
        $paypalInfo = $this->input->get();
          
        $data['item_number'] = $paypalInfo['item_number']; 
        $data['txn_id'] = $paypalInfo["tx"];
       
        
        $data['payment_amt'] = $paypalInfo["amt"];
        $data['currency_code'] = $paypalInfo["cc"];
        $data['status'] = $paypalInfo["st"];

        $this->load->database();
        
        $this->load->model('Writing_model');  
        
        $this->Writing_model->updateTransaction($data);
        
        //TOGGLE VIEW
         $this->load->library('session');
             if($this->session->userdata('logged_in')){
                 $client_email = ($this->session->userdata['logged_in']['client_email']);
                 $cust_name = ($this->session->userdata['logged_in']['client_name']);

                  $data['cust_name']= $cust_name; 
                  $this->load->view('Client/success', $data);
               }
        else
        {
            $this->load->view('success', $data);

        }
     }
     
     function cancel(){
        $this->load->library('session');
             if($this->session->userdata('logged_in')){
                 $client_email = ($this->session->userdata['logged_in']['client_email']);
                 $cust_name = ($this->session->userdata['logged_in']['client_name']);

                  $data['cust_name']= $cust_name; 
                  $this->load->view('Client/cancel', $data);
               }
        else
        {
        $this->load->view('cancel');

        }
     }
     
     function ipn(){
        //paypal return transaction details array
        $paypalInfo    = $this->input->post();

        $custom = $paypalInfo['custom'];
       // echo  $custom;
        //$itemnumber    = $paypalInfo["item_number"];
        $transactionid = $paypalInfo["txn_id"];
        $gross = $paypalInfo["payment_gross"];
        //$data['currency_code'] = $paypalInfo["mc_currency"];
        $email= $paypalInfo["payer_email"];
        $status   = $paypalInfo["payment_status"];

        $paypalURL = $this->paypal_lib->paypal_url;        
        $result    = $this->paypal_lib->curlPost($paypalURL,$paypalInfo);
        
        //check whether the payment is verified
        //if(eregi("VERIFIED",$result)){
            //insert the transaction data into the database
          $this->Writing_model->updateTransaction($custom,$transactionid, $gross,$email,$status);
       // }
    }
}