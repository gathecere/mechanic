                                       <h3 class="title">Testimonials</h3>
										<div class="separator"></div>
										<blockquote class="margin-clear">
											<p>You guys are the best, thank you! I hope I get 100%! Your reliable and so professional help is always worth using.</p>	
											<footer><cite title="Source Title">Steve  </cite></footer>
										</blockquote>
										<blockquote class="margin-clear">
											<p>Very well-written paper. Good diction and concise. Completed in a timely manner and finished my request for a simple revision very quickly.</p>	
											<footer><cite title="Source Title">Anne </cite></footer>
										</blockquote>
										<blockquote class="margin-clear">
											<p>Very effective writing and fast completion. Thank you for helping me out in a time of need. Much appreciated.</p>	
											<footer><cite title="Source Title">Brian </cite></footer>
										</blockquote>
										<blockquote class="margin-clear">
											<p>Very very good service. Thank you so much for the hard work! This paper is very important for me</p>	
											<footer><cite title="Source Title">Joseph </cite></footer>
										</blockquote>