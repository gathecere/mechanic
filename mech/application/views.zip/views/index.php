<?php include 'header.php' ?>

      <!-- header end -->



      <!-- banner start -->

      <!-- ================ -->

      <div class="banner">



        <!-- slideshow start -->

        <!-- ================ -->

        <div class="slideshow">

          

          <!-- slider revolution start -->

          <!-- ================ -->

          <div class="slider-banner-container">

            <div class="slider-banner">

              <ul>

                <!-- slide 1 start -->

                <li data-transition="random" data-slotamount="7" data-masterspeed="500" data-saveperformance="on" data-title="Writers Corp Website">

                

                <!-- main image -->

                <img src="<?php echo base_url('images/writerscorpslideone.png') ?>"  alt="writers corp slide one" data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat">



                <!-- LAYER NR. 1 -->

                <div class="tp-caption default_bg large sfr tp-resizeme"

                  data-x="0"

                  data-y="70" 

                  data-speed="600"

                  data-start="1200"

                  data-end="9400"

                  data-endspeed="600">Welcome to Writers Corp

                </div>



                <!-- LAYER NR. 2 -->

                <div class="tp-caption dark_gray_bg sfl medium tp-resizeme"

                  data-x="0"

                  data-y="170" 

                  data-speed="600"

                  data-start="1600"

                  data-end="9400"

                  data-endspeed="600"><i class="icon-check"></i>

                </div>



                <!-- LAYER NR. 3 -->

                <div class="tp-caption light_gray_bg sfb medium tp-resizeme"

                  data-x="50"

                  data-y="170" 

                  data-speed="600"

                  data-start="1600"

                  data-end="9400"

                  data-endspeed="600">Custom Papers

                </div>



                <!-- LAYER NR. 4 -->

                <div class="tp-caption dark_gray_bg sfl medium tp-resizeme"

                  data-x="0"

                  data-y="220" 

                  data-speed="600"

                  data-start="1800"

                  data-end="9400"

                  data-endspeed="600"><i class="icon-check"></i>

                </div>



                <!-- LAYER NR. 5 -->

                <div class="tp-caption light_gray_bg sfb medium tp-resizeme"

                  data-x="50"

                  data-y="220" 

                  data-speed="600"

                  data-start="1800"

                  data-end="9400"

                  data-endspeed="600">Quality Writing

                </div>



                <!-- LAYER NR. 6 -->

                <div class="tp-caption dark_gray_bg sfl medium tp-resizeme"

                  data-x="0"

                  data-y="270" 

                  data-speed="600"

                  data-start="2000"

                  data-end="9400"

                  data-endspeed="600"><i class="icon-check"></i>

                </div>



                <!-- LAYER NR. 7 -->

                <div class="tp-caption light_gray_bg sfb medium tp-resizeme"

                  data-x="50"

                  data-y="270" 

                  data-speed="600"

                  data-start="2000"

                  data-end="9400"

                  data-endspeed="600">Plagiarism Free Papers

                </div>



                <!-- LAYER NR. 8 -->

                <div class="tp-caption dark_gray_bg sfl medium tp-resizeme"

                  data-x="0"

                  data-y="320" 

                  data-speed="600"

                  data-start="2200"

                  data-end="9400"

                  data-endspeed="600"><i class="icon-check"></i>

                </div>



                <!-- LAYER NR. 9 -->

                <div class="tp-caption light_gray_bg sfb medium tp-resizeme"

                  data-x="50"

                  data-y="320" 

                  data-speed="600"

                  data-start="2200"

                  data-end="9400"

                  data-endspeed="600">Timely Delivery

                </div>



                <!-- LAYER NR. 10 -->

                <div class="tp-caption dark_gray_bg sfb medium tp-resizeme"

                  data-x="0"

                  data-y="370" 

                  data-speed="600"

                  data-start="2400"

                  data-end="9400"

                  data-endspeed="600">And Much More...

                </div>



                

                </li>

                <!-- slide 1 end -->



                <!-- slide 2 start -->

                 <li data-transition="random" data-slotamount="7" data-masterspeed="500" data-saveperformance="on" data-title="Writers Corp Website">

                

                <!-- main image -->

                <img src="<?php echo base_url('images/writerscorpservices.png') ?>"  alt="writers corp slide one" data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat">



                <!-- LAYER NR. 1 -->

                <div class="tp-caption default_bg large sfr tp-resizeme"

                  data-x="0"

                  data-y="70" 

                  data-speed="600"

                  data-start="1200"

                  data-end="9400"

                  data-endspeed="600">Our Services

                </div>



                <!-- LAYER NR. 2 -->

                <div class="tp-caption dark_gray_bg sfl medium tp-resizeme"

                  data-x="0"

                  data-y="170" 

                  data-speed="600"

                  data-start="1600"

                  data-end="9400"

                  data-endspeed="600"><i class="icon-check"></i>

                </div>



                <!-- LAYER NR. 3 -->

                <div class="tp-caption light_gray_bg sfb medium tp-resizeme"

                  data-x="50"

                  data-y="170" 

                  data-speed="600"

                  data-start="1600"

                  data-end="9400"

                  data-endspeed="600">Custom Paper Writing

                </div>



                <!-- LAYER NR. 4 -->

                <div class="tp-caption dark_gray_bg sfl medium tp-resizeme"

                  data-x="0"

                  data-y="220" 

                  data-speed="600"

                  data-start="1800"

                  data-end="9400"

                  data-endspeed="600"><i class="icon-check"></i>

                </div>



                <!-- LAYER NR. 5 -->

                <div class="tp-caption light_gray_bg sfb medium tp-resizeme"

                  data-x="50"

                  data-y="220" 

                  data-speed="600"

                  data-start="1800"

                  data-end="9400"

                  data-endspeed="600">Research Papers

                </div>



                <!-- LAYER NR. 6 -->

                <div class="tp-caption dark_gray_bg sfl medium tp-resizeme"

                  data-x="0"

                  data-y="270" 

                  data-speed="600"

                  data-start="2000"

                  data-end="9400"

                  data-endspeed="600"><i class="icon-check"></i>

                </div>



                <!-- LAYER NR. 7 -->

                <div class="tp-caption light_gray_bg sfb medium tp-resizeme"

                  data-x="50"

                  data-y="270" 

                  data-speed="600"

                  data-start="2000"

                  data-end="9400"

                  data-endspeed="600">IT assignments

                </div>



                <!-- LAYER NR. 8 -->

                <div class="tp-caption dark_gray_bg sfl medium tp-resizeme"

                  data-x="0"

                  data-y="320" 

                  data-speed="600"

                  data-start="2200"

                  data-end="9400"

                  data-endspeed="600"><i class="icon-check"></i>

                </div>



                <!-- LAYER NR. 9 -->

                <div class="tp-caption light_gray_bg sfb medium tp-resizeme"

                  data-x="50"

                  data-y="320" 

                  data-speed="600"

                  data-start="2200"

                  data-end="9400"

                  data-endspeed="600">Dissertation Writing

                </div>



                <!-- LAYER NR. 10 -->

                <div class="tp-caption dark_gray_bg sfb medium tp-resizeme"

                  data-x="0"

                  data-y="370" 

                  data-speed="600"

                  data-start="2400"

                  data-end="9400"

                  data-endspeed="600">And Much More...

                </div>



                

                </li>

               

                <!-- slide 2 end -->



                <!-- slide 3 start -->

               
              



                <!-- LAYER NR. 11 -->

               

                <!-- slide 3 end -->



              </ul>

              <div class="tp-bannertimer tp-bottom"></div>

            </div>

          </div>

          <!-- slider revolution end -->



        </div>

        <!-- slideshow end -->



      </div>

      <!-- banner end -->



      <!-- page-top start-->

      <!-- ================ -->

      <div class="page-top">

        <div class="container">

          <div class="row">

            <div class="col-md-8 col-md-offset-2">

              <div class="call-to-action">

                <h1 class="title">Welcome to Writers Corp</h1>

                <p>

Welcome to Writers Corp the home of quality and diverse written papers.We are skilled in writing academic papers across various disciplines. Our team of experienced writers and support staff ensure that your orders are attended to without delays. Our writers are highly qualified and thus you are guaranteed high quality work affordably.



</p>

             



                <!-- Modal -->

               

              

                <a href="<?php echo base_url('professionalwriting/order_now'); ?>" class="btn btn-default contact">ORDER NOW <i class="pl-10 fa fa-plus"></i></a>

              </div>

            </div>

          </div>

        </div>

      </div>

      <section class="main-container" style="background: #E5E5E5;">

        <div class="container">
          <div class="row">

            <!-- main start -->
            <!-- ================ -->
            <div class="main col-md-12">

              <!-- page-title start -->
              <!-- ================ -->
              <h1 class="page-title text-center">How it works</h1>
              <div class="separator"></div>
              <!-- page-title end -->
              
              <div class="row">
                <div class="col-md-6">
                  <div class="box-style-3 right animated fadeInUpSmall">
                    <div class="icon-container default-bg">
                      <i class="fa fa-plus"></i>
                    </div>
                    <div class="body">
                      <h2><span class="badge">1</span> Submit order details</h2>
                      <p>Issue instructions for your paper in the order form.</p>
                     
                    </div>
                  </div>
                  <div class="box-style-3 right animated fadeInUpSmall">
                    <div class="icon-container default-bg">
                      <i class="fa fa-credit-card"></i>
                    </div>
                    <div class="body">
                      <h2><span class="badge">2</span> Make your payment</h2>
                      <p>Your paper is processed by a secure system. We accept major payment companies</p>
                     
                    </div>
                  </div>
                  <div class="box-style-3 right animated fadeInUpSmall">
                    <div class="icon-container default-bg">
                      <i class="fa fa-edit"></i>
                    </div>
                    <div class="body">
                      <h2><span class="badge">3</span> The writing process</h2>
                      <p>We will keep you updated during the writing process</p>
                     
                    </div>
                  </div>
                    <div class="box-style-3 right animated fadeInUpSmall">
                    <div class="icon-container default-bg">
                      <i class="fa fa-download"></i>
                    </div>
                    <div class="body">
                      <h2><span class="badge">4</span> Access your paper</h2>
                      <p>You will be able to access your paper via email or client panel once the order is complete</p>
                     
                    </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="space hidden-lg hidden-md"></div>
                  <img class="animated fadeInUpSmall" src="<?php echo base_url('images/writerscorpart.png'); ?>" alt="article writing site">
                </div>
              </div>
              <div class="space"></div>

            </div>
            <!-- main end -->

          </div>
        </div>
      </section>

      <!-- page-top end -->
      


      <!-- main-container start -->

      <!-- ================ -->

      <section class="main-container gray-bg">



        <!-- main start -->

        <!-- ================ -->

        <div class="main">

          <div class="container">

            <div class="row">

              <div class="col-md-12">

                <h1 class="text-center title">Our Guarantees</h1>

                <div class="separator"></div>

                

                <div class="row">

                  <div class="col-sm-4">

                    <div class="box-style-1 white-bg object-non-visible" data-animation-effect="fadeInUpSmall" data-effect-delay="0">

                      <i class="fa fa-edit"></i>

                      <h2>Professional writers</h2>

                      <p>At Writers Corp our global writing staff includes experienced ENL and ESL academic writers in a variety of disciplines. This enables us find the most appropriate writer for any type of task.</p>

                      

                    </div>

                  </div>

                  <div class="col-sm-4">

                    <div class="box-style-1 white-bg object-non-visible" data-animation-effect="fadeInUpSmall" data-effect-delay="200">

                      <i class="fa fa-thumbs-up"></i>

                      <h2>100% money-back guarantee</h2>

                      <p>Our Money Back Guarantee gives you the right to request and receive a refund at any stage of your order if anything goes wrong.</p>

                     

                    </div>

                  </div>

                  <div class="col-sm-4">

                    <div class="box-style-1 white-bg object-non-visible" data-animation-effect="fadeInUpSmall" data-effect-delay="400">

                      <i class="fa fa-search-plus"></i>

                      <h2>Plagiarism-free papers</h2>

                      <p>Our academic writers write all papers from scratch. In addition, we check each paper for plagiarism before delivering it to our customers. This way we are sure the paper is original,custom and unique.</p>

                     

                    </div>

                  </div>

                </div>

              </div>

            </div>

          </div>

        </div>

        <!-- main end -->



      </section>

      <!-- main-container end -->



      <!-- section start -->

      <!-- ================ -->

      <div class="section clearfix">

        <div class="container">

          <div class="row">

            <div class="col-md-12">

              <h1 class="text-center"></h1>

             

              

              <br>

              <div class="row">

                <div class="col-md-8">

                 

                 <?php include 'calculation.php'; ?>

                 

                </div>            

                 

                  

                 

                <div class="col-md-4">

                <div class="side vertical-divider-left">

                    

                     <h2 class="text-center">Testimonials</h2>

                    <div class="separator"></div>

                    <blockquote class="margin-clear">

                      <p>You guys are the best, thank you! I hope I get 100%! Your reliable and so professional help is always worth using.</p> 

                      <footer><cite title="Source Title">Steve  </cite></footer>

                    </blockquote>

                    <blockquote class="margin-clear">

                      <p>Very well-written paper. Good diction and concise. Completed in a timely manner and finished my request for a simple revision very quickly.</p>  

                      <footer><cite title="Source Title">Anne </cite></footer>

                    </blockquote>

                    <blockquote class="margin-clear">

                      <p>Very effective writing and fast completion. Thank you for helping me out in a time of need. Much appreciated.</p>  

                      <footer><cite title="Source Title">Brian </cite></footer>

                    </blockquote>

                   

                    

                    </div>

                </div>

              </div>

              <br>

            </div>

          </div>

        </div>

      </div>

      <!-- section end -->



      <!-- section start -->

      <!-- ================ -->

      

      <!-- section end -->



      <!-- section start -->

      <!-- ================ -->

      <div class="section clearfix" id="tele">

        <div class="container">

          <div class="row">

            <div class="col-md-12">



              <h1 class="text-center">Why Choose Writers Corp?</h1>

              <div class="separator"></div>

             

                <!-- Tabs Arrow -->

                

                

                <!-- Nav tabs -->

                <ul class="nav nav-tabs" role="tablist">

                  <li class="active"><a href="#tab55" role="tab" data-toggle="tab"><i class="fa fa-magic pr-10"></i> Custom Papers</a></li>

                  <li><a href="#tab77" role="tab" data-toggle="tab"><i class="fa fa-life-saver pr-10"></i> Top Notch 24/7 Support</a></li>

                  <li><a href="#tab88" role="tab" data-toggle="tab"><i class="fa fa-expand pr-10"></i> Fast Delivery for Urgent Papers</a></li>

                  <li><a href="#tab99" role="tab" data-toggle="tab"><i class="fa fa-file-o pr-10"></i> Different Paper Formats</a></li>

                </ul>



                <!-- Tab panes -->

                <div class="tab-content">

                  <div class="tab-pane fade in active" id="tab55">

                    <h1 class="text-center title">Custom Papers</h1>

                    <div class="space"></div>

                    <div class="row">



                   

                      

                      <div class="col-md-8 col-md-offset-2">

                        <p>All custom papers are prepared by qualified writers according to your instructions and, therefore, exclude any chance of plagiarism. We have a large staff of academic writers, including native speakers from the USA, the UK, Canada, and Australia. Thus, we can quickly find the most suitable one for your specific order.</p>

                       

                      </div>

                    </div>

                  </div>

                  <div class="tab-pane fade" id="tab77">

                    <h1 class="text-center title">Top Notch 24/7 Support</h1>

                    <div class="space"></div>

                    <div class="row">

                      

                      <div class="col-md-8 col-md-offset-2">

                        <p>Need help and support? Don’t hesitate to contact our 24/7 support team. Our team members are available via email, live chat, and phone. Our crew is friendly and ready to help you with any issue. </p>

                       

                      </div>

                    </div>

                  </div>

                  <div class="tab-pane fade" id="tab88">

                    <h1 class="text-center title">Fast Delivery for Urgent Papers</h1>

                    <div class="space"></div>

                    <div class="row">

                      

                      <div class="col-md-8 col-md-offset-2">

                        <p>The deadline is close and you still have no idea how to write your essay, research, or article review? With us, you can get a well-researched and professionally prepared paper overnight or even within 8 hours if you are pressed for time.</p>

                       

                      </div>

                    </div>

                  </div>

                  <div class="tab-pane fade" id="tab99">

                    <h1 class="text-center title"> Different Paper Formats</h1>

                    <div class="space"></div>

                    <div class="row">

                      

                      <div class="col-md-8 col-md-offset-2">

                        <p>Have difficulties with citing sources? Our writers are an old hand at proper referencing and can easily cope with MLA / APA / Harvard / Chicago / Turabian or any other formatting style.</p>

                       

                      </div>

                    </div>

                  </div>

                </div>

              </div>

              <!-- tabs end -->

        

            </div>

          </div>

        </div>

        <section class="main-container gray-bg">



        <!-- main start -->

        <!-- ================ -->

        <div class="main">

          <div class="container">

            <div class="row">

              <div class="col-md-12">

                <h1 class="text-center title">Latest Work</h1>

                <div class="separator"></div>

                

                <div class="row">
                <?php 

                   foreach ($previous->result() as $row) {
                     # code...
                 

                ?>

                  <div class="col-sm-4">

                    <div class="box-style-1 white-bg object-non-visible" data-animation-effect="fadeInUpSmall" data-effect-delay="0">

                     

                      <h2><?php echo $row->previous_title; ?></h2>

                      <p>
                        <?php echo mb_strimwidth("$row->previous_paper", 0, 200, "..."); ?>
                      </p>

                      

                    </div>

                  </div>
                  <?php
                   }
                   ?>

                  

                

                </div>

              </div>

            </div>

          </div>

        </div>

        <!-- main end -->



      </section>


      </div>

      <!-- section end -->



      <!-- section start -->

      <!-- ================ -->

     

      <!-- section end -->



      <!-- section start -->

      <!-- ================ -->



      <!-- section end -->



      <!-- section start -->

      <!-- ================ -->

      



      <!-- section end -->



      <!-- footer start (Add "light" class to #footer in order to enable light footer) -->

      <!-- ================ -->

      <?php include 'footer.php'; ?>


      
    <script type="text/javascript">

    $(document).ready(function() {

    $(".pure-menu-list a").click(function(event) {

        event.preventDefault();

        $(this).parent().addClass("current");

        $(this).parent().siblings().removeClass("current");

        var tab = $(this).attr("href");

        $(".tab-content").not(tab).css("display", "none");

         

        $(tab).fadeIn();

    });

});

 </script>

 <script>

 

 $(document).ready(function() {

    $(".tabby-menu a").click(function(event) {

        event.preventDefault();

        $(this).parent().addClass("current");

        $(this).parent().siblings().removeClass("current");

        var tab = $(this).attr("href");

        $(".tabby-content").not(tab).css("display", "none");

        $(tab).fadeIn();

    });

});

 </script>

 <!--Start of Tawk.to Script-->

<!--End of Tawk.to Script-->

    <script>

/*

This source is shared under the terms of LGPL 3

www.gnu.org/licenses/lgpl.html



You are free to use the code in Commercial or non-commercial projects

*/



 //Set up an associative array

 //The keys represent the size of the cake

 //The values represent the cost of the cake i.e A 10" cake cost's $35

           var cake_prices = new Array();

             <?php 

            

           foreach ($hi->result() as $row) 

           {

              

            ?>       

           cake_prices["<?php echo $row->level_deadline;  ?>"]=<?php echo $row->level_highschool;  ?>;

           <?php } ?>

           

           

           var under_grad = new Array();

           <?php 

            

           foreach ($undergrad_lo->result() as $row) 

           {

              

            ?>       

           under_grad["<?php echo $row->level_deadline;  ?>"]=<?php echo $row->level_undergradlower;  ?>;

           <?php } ?>

           

           var upper_grad = new Array();

           <?php 

            

           foreach ($undergrad_hi->result() as $row) 

           {

              

            ?>      

           upper_grad["<?php echo $row->level_deadline;  ?>"]=<?php echo $row->level_undergradupper;  ?>;

           <?php } ?>

           

           

           var masters_grad = new Array();

           <?php 

            

           foreach ($mast->result() as $row) 

           {

              

            ?>      

           masters_grad["<?php echo $row->level_deadline;  ?>"]=<?php echo $row->level_masters;  ?>;

           <?php } ?>

           

           

           var doctoral_grad = new Array();

           <?php 

            

           foreach ($doct->result() as $row) 

           {

              

            ?>      

          doctoral_grad["<?php echo $row->level_deadline;  ?>"]=<?php echo $row->level_doctoral;  ?>;

           <?php } ?>

           

           //Set up an associative array 

           //The keys represent the filling type

           //The value represents the cost of the filling i.e. Lemon filling is $5,Dobash filling is $9

           //We use this this array when the user selects a filling from the form

           

           

             

             

          // getCakeSizePrice() finds the price based on the size of the cake.

          // Here, we need to take user's the selection from radio button selection

          function getCakeSizePrice()

          {  

              var rates = document.getElementsByName('price');

          var rate_value;

          for(var i = 0; i < rates.length; i++){

              if(rates[i].checked){

                  rate_value = cake_prices[rates[i].value];

              }

          }

            return rate_value;

          }



          function getundergradPrice()

          {  

              var rates = document.getElementsByName('see');

          var rate_value;

          for(var i = 0; i < rates.length; i++){

              if(rates[i].checked){

                  rate_value = under_grad[rates[i].value];

              }

          }

            return rate_value;

          }



          function getundergradUpper()

          {  

               var rates = document.getElementsByName('upper');

          var rate_value;

          for(var i = 0; i < rates.length; i++){

              if(rates[i].checked){

                  rate_value = upper_grad[rates[i].value];

              }

          }

            return rate_value;

          }



          function getMasters()

          {  

             var rates = document.getElementsByName('masters');

          var rate_value;

          for(var i = 0; i < rates.length; i++){

              if(rates[i].checked){

                  rate_value = masters_grad[rates[i].value];

              }

          }

            return rate_value;

          }

          function getDoctoral()

          {  

             var rates = document.getElementsByName('doctoral');

          var rate_value;

          for(var i = 0; i < rates.length; i++){

              if(rates[i].checked){

                  rate_value = doctoral_grad[rates[i].value];

              }

          }

            return rate_value;

          }

          //This function finds the filling price based on the 

          //drop down selection





          //candlesPrice() finds the candles price based on a check box selection





          function pages()

          {

              //This local variable will be used to decide whether or not to charge for the inscription

              //If the user checked the box this value will be 20

              //otherwise it will remain at 0

              

              //Get a refernce to the form id="cakeform"

               var x = document.getElementById("pages").value;

              //If they checked the box set inscriptionPrice to 20

              

              //finally we return the inscriptionPrice

              return x;

          }



          function calculateWords()

          {

              //Here we get the total price by calling our function

              //Each function returns a number so by calling them we add the values they return together

              var cakePrice = 275 * pages();

              

              //display the result

              var divobj = document.getElementById('words');

              divobj.style.display='inline';

               divobj.style.left='40px';

              divobj.innerHTML = cakePrice+' '+"words";



          }

               



          function calculateUnder()

          {

              //Here we get the total price by calling our function

              //Each function returns a number so by calling them we add the values they return together

              var cakePrice = getundergradPrice() * pages();

              

              //display the result

              var divobj = document.getElementById('totalundergrad');

              divobj.style.display='block';

              divobj.innerHTML = "<span class='kivutha'>Total Price:</span> <span id='dollar'>"+"$"+"<input type='hidden' name='amountunder' value='"+cakePrice+ "'  >"+cakePrice+"</span>";



          }

          function calculateUpper()

          {

              //Here we get the total price by calling our function

              //Each function returns a number so by calling them we add the values they return together

              var cakePrice = getundergradUpper() * pages();

              

              //display the result

              var divobj = document.getElementById('upper');

              divobj.style.display='block';

              divobj.innerHTML = "<span class='kivutha'>Total Price:</span> <span id='dollar'>"+"$"+"<input type='hidden' name='amountupper' value='"+cakePrice+ "'  >"+cakePrice+"</span>";

          }

          function calculateMasters()

          {

              //Here we get the total price by calling our function

              //Each function returns a number so by calling them we add the values they return together

              var cakePrice = getMasters() * pages();

              

              //display the result

              var divobj = document.getElementById('mastersid');

              divobj.style.display='block';

             divobj.innerHTML = "<span class='kivutha'>Total Price:</span> <span id='dollar'>"+"$"+"<input type='hidden' name='amountmasters' value='"+cakePrice+ "'  >"+cakePrice+"</span>";



          }



          function calculateDoctoral()

          {

              //Here we get the total price by calling our function

              //Each function returns a number so by calling them we add the values they return together

              var cakePrice = getDoctoral() * pages();

              

              //display the result

              var divobj = document.getElementById('doctoralid');

              divobj.style.display='block';

              

              divobj.innerHTML = "<span class='kivutha'>Total Price:</span> <span id='dollar'>"+"$"+"<input type='hidden' name='amountdoctoral' value='"+cakePrice+ "'  >"+cakePrice+"</span>";



          }



          function calculateTotal()

          {

              //Here we get the total price by calling our function

              //Each function returns a number so by calling them we add the values they return together

              var cakePrice = getCakeSizePrice() * pages();

              

              //display the result

              var divobj = document.getElementById('totalPrice');

              divobj.style.display='block';

               divobj.style.display='visible';

              divobj.innerHTML = "<span class='kivutha'>Total Price:</span> <span id='dollar'>"+"$"+"<input type='hidden' name='amounthigh' value='"+cakePrice+ "'  >"+cakePrice+"</span>";

               

               



          }





        </script>



        <script>

$(document).ready(function(){

    $(".select").change(function(){

         var _curr_tab = $(".select option:selected").html().toLowerCase();

         $(".tab_class").removeClass("active"); // Will remove .active from all "a"

         $("#"+_curr_tab).addClass("active"); // Will add .active to a having id _curr_tab

        showProduct(_curr_tab , document.getElementById(_curr_tab));



     });





    $(".tab_class").click(function(){

      var id=$(this).attr("id");

        showProduct(id, document.getElementById(id));

    });



});



function showProduct(a,b)

{

$(".tab_class").removeClass("active");

$("#"+a).addClass("active");

}

</script>