<?php include 'admin_header.php' ?>
<div class="content-wrapper">
  <section class="content-header">
        <ol class="breadcrumb">
            <li><a href="#" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a></li>
            <li class="active">Add Sample</li>
        </ol>    
  </section>
 

   <br>
    <br>
    
  
  <div class="container-fluid">
   
     <div class="box">
     	<div class="col-md-12">
                <div class="box box-info">
                    <div class="box-header with-border">
                         <h3 class="box-title">Add Sample</h3>
                          <div class="box-tools">
                            <div class="input-group input-group-sm" style="width: 150px;">
                             
                            </div>
                          </div>
                    </div>

                     <?php 
					   if(isset($success))
					   {
					   	?>
					   	<div class="alert alert-success">
					   	 <?php
					   	  echo $success;
					   	  ?>
					   	 </div>
					   	 <?php
					   }

					 ?>


             <?php 
             if(isset($error))
             {
              ?>
              <div class="alert alert-warning">
               <?php
                echo $error;
                ?>
               </div>
               <?php
             }

           ?>

          

                      <!--No Label Form-->

                      <!--===================================================-->

                      
			    <form action="<?php echo base_url('Admin/add_sample_process'); ?>" method="post" style="padding:10px 25px;" enctype="multipart/form-data">
				  <div class="form-group">
				    <label for="email">Sample Title:</label>
				    <input type="text" class="form-control" name="sample_title" id="email" placeholder="Paper title" required>
				  </div>
				   <div class="form-group">
				    <label for="email">Sample First Paragraph:</label>
				    <textarea name="sample_paragraph" class="form-control" name id="email" placeholder="First paragraph here" required></textarea>
				  </div>
           <div class="form-group">
            <label for="email">Sample Whole Paper:</label>
            <textarea name="sample_paper" class="form-control" rows="15" name id="email" placeholder="Whole sample here" required></textarea>
          </div>
				  <div class="form-group">
            <div class="row">
               <div class="col-md-6">

    				    <label for="pwd">Number of Pages:</label>
    				    <input type="number" name="sample_pages" class="form-control" id="pwd" placeholder="Number of pages" required>

               </div>

               <div class="col-md-6">

                <label for="pwd">Subject Area:</label>
                <input type="text" name="sample_subject_area" class="form-control" id="pwd" placeholder="subject" required>
                
               </div>
            </div>
				  </div>
           <div class="form-group">
            <div class="row">
               <div class="col-md-4">

                <label for="pwd">Academic Level:</label>
               <!--  <input type="text" name="sample_academic_level" class="form-control" id="pwd" placeholder="Academic Level" required> -->

                     <select class="form-control" name="sample_academic_level" required>
                                           
                            <?php

                              foreach ($academic_level->result_array() as $row) {
                             
                            ?>

                              <option value="<?php echo $row['level_id']; ?>"><?php echo $row['level_name']; ?></option>
                            <?php
                              }
                            ?>
                                            
                      </select>

               </div>

                <div class="col-md-4">

                <label for="pwd">Sample Upload:</label>
                <input type="file" name="userfile"  id="pwd" placeholder="keywords" required>

               </div>

               <div class="col-md-4">

                <label for="pwd">No. of Sources:</label>
                <input type="number" name="sample_number_sources" class="form-control" id="pwd" placeholder="Sources" required>
                
               </div>
            </div>
          </div>
          <div class="form-group">
            <div class="row">
               <div class="col-md-4">

                <label for="pwd">Urgency:</label>
                <input type="number" name="sample_urgency" class="form-control" id="pwd" placeholder="Urgency" required>

               </div>

                <div class="col-md-4">

                <label for="pwd">Price:</label>
                <input type="text" name="sample_price" class="form-control" id="pwd" placeholder="Price" required>

               </div>

               <div class="col-md-4">

                <label for="pwd">Style:</label>
               <!--  <input type="text" name="sample_style" class="form-control" id="pwd" placeholder="Style" required> -->
                <select class="form-control" name="sample_style" required>
                                           
                            <?php

                              foreach ($style->result_array() as $row) {
                             
                            ?>

                              <option value="<?php echo $row['format_id']; ?>"><?php echo $row['format_name']; ?></option>
                            <?php
                              }
                            ?>
                                            
                      </select>
                
               </div>
            </div>
          </div>
          
				  
				 
				  <button type="submit" class="btn btn-primary">Submit</button>

				</form> 

                      <!--===================================================-->

                      <!--End No Label Form-->

          

                  </div>



              </div>

            

            <!--===================================================-->

            <!--END MAIN NAVIGATION-->


       </div>
    </div>

</div>

        



        <!-- FOOTER -->

        <!--===================================================-->

       <?php include 'admin_footer.php'; ?>