<?php include 'admin_header.php' ?>
<div class="content-wrapper">
  <section class="content-header">
        <ol class="breadcrumb">
            <li><a href="#" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a></li>
            <li class="active">All Orders</li>
        </ol>    
  </section>
 

   <br>
    <br>
    
  
  <div class="container-fluid">

  	   <?php 
					   if(isset($success))
					   {
					   	?>
					   	<div class="alert alert-success">
					   	 <?php
					   	  echo $success;
					   	  ?>
					   	 </div>
					   	 <?php
					   }

					 ?>
   
     <div class="box">
                <div class="box box-info">
                    <div class="box-header with-border">
                         <h3 class="box-title">All Orders</h3>
                          <div class="box-tools">
                            <div class="input-group input-group-sm" style="width: 150px;">
                             
                            </div>
                          </div>
                    </div>
           <div class="box-body table-responsive no-padding">
                      <table class="table table-striped" style="font-size: 12px;">
                <thead>
                   <tr>
                                    
                                    <th>ORDER ID</th>
                                    <th>Payment Status</th>
                                     <th>Amount in $</th>
                                     
                                    <th>Order Topic</th>
                                    <!-- <th>Order Instructions</th> -->
                                    <th>Files</th>
                                    <th>Cust Name</th>
                                     <!-- <th>Cust Phone</th> -->
                                     <th>Cust Email</th>
                                     <!--  <th>Upload</th> -->
                                      <th>Action</th>
                                    
                                   
                                   
                                    
                                </tr>
                </thead>
                <tbody>
                    <?php 
              
                                                        
                                                         foreach ($all->result() as $row) 
{
                                                               
                                                                    
                                                                 
                                                        
              ?>
                              
                    <tr>
                    
                                         <td><?php echo $row->order_id; ?></td>
                                         <td><?php echo $row->order_paymentstatus; ?></td>
                                         <td><?php echo $row->order_payeramount; ?></td>
                                          <td><?php echo $row->order_topic; ?></td>
                                          <!--  <td><?php //echo $row->order_instructions; ?></td> -->
                                           
                                           <?php
                                             if($row->order_files==NULL)
                                             {  ?>
                                             
                                                 <td><?php echo 'NO FILES' ; ?></a></td>
                                       
                                             
                                         <?php    } 
                                         
                                            else
                                                  {
                                                  
                                                  
                                                       $category =$row->order_files;
                               $pieces = explode(",", $category); 
                                 $number=count($pieces);
                                  $direct='/files'; 
                            echo  '<td>';
                          for($i=0;$i<$number;$i++){
                         
                                                 ?>
                                         
                                             <a href="<?php echo base_url($direct)."/".$pieces[$i]; ?>"><?php echo  $pieces[$i] ; ?></a>
                                             <br>
                                                  
                                           <?php      
                                              }
                                              echo '</td>';
                                           }
                                         ?>
                                         
                                        <td><?php echo $row->cust_name; ?></td>  
                                         <!--  <td><?php// echo $row->cust_phone; ?></td> -->
                                          <td><?php echo $row->cust_email; ?></td>
                                            <td><a href="#"><i class="fa fa-cog" data-toggle="modal" data-target="#myModal<?php echo $row->order_id; ?>"></i></a>


                                           <div id="myModal<?php echo $row->order_id; ?>" class="modal fade" role="dialog">

                                                              <div class="modal-dialog">



                                                                <!-- Modal content-->

                                                                <div class="modal-content">

                                                                  <div class="modal-header">

                                                                    <button type="button" class="close" data-dismiss="modal">&times;</button>

                                                                    <h4 class="modal-title">Settings for ORDER ID: <?php echo $row->order_id; ?> </h4>

                                                                  </div>

                                                                  <div class="modal-body">
<!-- 
                                                                     <h4><a href="<?php // echo site_url("admin/update/$row->order_id"); ?>">Approve Order</a></h4> -->


                                                                     <h4><a href="<?php  echo site_url("admin/order_details/$row->order_id"); ?>">Order Details</a></h4>
                                                                      <h4><a  Onclick="return confirm('Are you sure you want to delete this record?')"  href="<?php  echo site_url("admin/delete_entry/$row->order_id"); ?>">Delete Order</a></h4>

                                                                    

                                                                  

                                                                   <!--  <h4><a href='<?php //echo base_url("Admin/delete_ad/$row->ad_id");  ?>'' Onclick="return confirm('Are you sure you want to delete this record?')" >Delete</a></h4> -->

                                                                  </div>

                                                                  <div class="modal-footer">

                                                                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

                                                                  </div>

                                                                </div>



                                                              </div>

                                                            </div>
                                     </form>  
                                         
                                </tr>
                         
                      <?php } ?>
                </tbody>
              </table>
						  </div>

                                      </div>

                      <!--===================================================-->

                      <!--End No Label Form-->

          

                  </div>

              </div>

          </div>

  

                <!--===================================================-->

                <!--End page content-->



         
            <!--===================================================-->

            <!--END CONTENT CONTAINER-->





            

            <!--ASIDE-->

            <!--===================================================-->

          

           

            <!--===================================================-->

            <!--END ASIDE-->



            

            <!--MAIN NAVIGATION-->

            <!--===================================================-->




        



        <!-- FOOTER -->

        <!--===================================================-->

       <?php include 'admin_footer.php'; ?>