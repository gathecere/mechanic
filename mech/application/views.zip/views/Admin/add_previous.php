<?php include 'admin_header.php' ?>
<div class="content-wrapper">
  <section class="content-header">
        <ol class="breadcrumb">
            <li><a href="#" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a></li>
            <li class="active">Add Previous Papers</li>
        </ol>    
  </section>
 

   <br>
    <br>
    
  
  <div class="container-fluid">
   
     <div class="box">
     	<div class="col-md-12">
                <div class="box box-info">
                    <div class="box-header with-border">
                         <h3 class="box-title">Add Previous Papers</h3>
                          <div class="box-tools">
                            <div class="input-group input-group-sm" style="width: 150px;">
                             
                            </div>
                          </div>
                    </div>

                     <?php 
					   if(isset($success))
					   {
					   	?>
					   	<div class="alert alert-success">
					   	 <?php
					   	  echo $success;
					   	  ?>
					   	 </div>
					   	 <?php
					   }

					 ?>

          

                      <!--No Label Form-->

                      <!--===================================================-->

                      
			    <form action="<?php echo base_url('Admin/add_previous_process'); ?>" method="post" style="padding:10px 25px;">
				  <div class="form-group">
				    <label for="email">Title:</label>
				    <input type="text" class="form-control" name="title" id="email" placeholder="Paper title" required>
				  </div>
				   <div class="form-group">
				    <label for="email">Description:</label>
				    <textarea name="description" class="form-control" name id="email" placeholder="First paragraph here" required></textarea>
				  </div>
				  <div class="form-group">
				    <label for="pwd">Keywords:</label>
				    <input type="text" name="keywords" class="form-control" id="pwd" placeholder="keywords" required>
				  </div>
				   <div class="form-group">
				    <label for="email">Paper:</label>
				    <textarea name="paper" rows="15" class="form-control" name id="email" placeholder="Whole paper here" required></textarea>
				  </div>
				 
				  <button type="submit" class="btn btn-primary">Submit</button>

				</form> 

                      <!--===================================================-->

                      <!--End No Label Form-->

          

                  </div>



              </div>

            

            <!--===================================================-->

            <!--END MAIN NAVIGATION-->


       </div>
    </div>

</div>

        



        <!-- FOOTER -->

        <!--===================================================-->

       <?php include 'admin_footer.php'; ?>