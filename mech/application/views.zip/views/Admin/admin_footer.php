
 <!-- <style>
.buttons-print {
  background-color: red;
  color: white;
}
.buttons-excel {
  background-color: blue;
  color: white;

</style> -->
<!-- Main Footer -->
<footer class="main-footer">
            <!-- To the right -->
            <div class="pull-right hidden-xs">
              
            </div>
            <!-- Default to the left -->
            <strong>Copyright &copy; 2020 <a href="https://writers-corp.net">Writers Corp </a>.</strong> All rights reserved.
        </footer>

      
    </div>
    <!-- ./wrapper -->



    <!-- REQUIRED JS SCRIPTS -->

    <!-- jQuery 3 -->
    
     <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.js"></script>
    <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>

    <script type="text/javascript" src="<?php echo base_url('bower_components/jquery/dist/jquery.validate.js') ?> "></script>  
    <!-- Bootstrap 3.3.7 -->
    <script src="<?php echo base_url('bower_components/bootstrap/dist/js/bootstrap.min.js'); ?>"></script>
  
    <script src="<?php echo base_url('bower_components/select2/dist/js/select2.full.min.js'); ?>"></script>
<script src="<?php echo base_url('plugins/input-mask/jquery.inputmask.js') ?>"></script>
<script src="<?php echo base_url('plugins/input-mask/jquery.inputmask.date.extensions.js') ?>"></script>
<script src="<?php echo base_url('plugins/input-mask/jquery.inputmask.extensions.js') ?>"></script>
    <!-- AdminLTE App -->

    <!-- date-range-picker -->
<script src="<?php echo base_url('bower_components/moment/min/moment.min.js') ?>"></script>

<!-- bootstrap color picker -->
<script src="<?php echo base_url('bower_components/bootstrap-colorpicker/dist/js/bootstrap-colorpicker.min.js') ?>"></script>
<!-- bootstrap time picker -->
<!-- <script src="<?php //echo base_url('plugins/timepicker/bootstrap-timepicker.min.js') ?>"></script> -->
<!-- SlimScroll -->
<script src="<?php echo base_url('bower_components/jquery-slimscroll/jquery.slimscroll.min.js') ?>"></script>
<!-- iCheck 1.0.1 -->
<script src="<?php echo base_url('plugins/iCheck/icheck.min.js') ?>"></script>
<!-- FastClick -->
<script src="<?php echo base_url('bower_components/fastclick/lib/fastclick.js') ?>"></script>

<!--<script src="<?php //echo base_url('dist/js/buttons.flash.min.js'); ?>"></script> -->
<!-- <script src="<?php //echo base_url('dist/js/jszip.min.js'); ?>"></script> -->
<!-- <script src="<?php //echo base_url('dist/js/vfs_fonts.js'); ?>"></script> -->
<!-- <script src="<?php //echo base_url('dist/js/buttons.html5.min.js'); ?>"></script> -->
<script src="<?php echo base_url('js/jquery-jvectormap-2.0.3.min.js'); ?>"></script>
<script src="<?php echo base_url('js/mill.js'); ?>"></script>

<script src="<?php echo base_url('dist/js/dataTables.buttons.min.js'); ?>"></script>
<script src="<?php echo base_url('dist/js/buttons.print.min.js'); ?>"></script>

    <script src="<?php echo base_url('dist/js/adminlte.min.js') ?>"></script>


   
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>



    
     



  

    <!-- Optionally, you can add Slimscroll and FastClick plugins.
     Both of these plugins are recommended to enhance the
     user experience. -->


  
<script src="<?php echo base_url('datetimepicker/build/jquery.datetimepicker.full.js') ?>"></script>

<script>




$('#demo').datetimepicker({

});


</script>

<script>

</script>


 
    <script src="<?php echo base_url('plugins/morris-js/morris.min.js') ?>"></script>
  <script src="<?php echo base_url('plugins/morris-js/raphael-js/raphael.min.js') ?>"></script>


   


    
    <!--Custom script [ DEMONSTRATION ]-->
    <!--===================================================-->
   
    



</body>


</html>
