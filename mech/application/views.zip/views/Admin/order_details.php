<?php include 'admin_header.php' ?>
<div class="content-wrapper">
  <section class="content-header">
        <ol class="breadcrumb">
            <li><a href="#" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a></li>
            <li class="active">Order Details</li>
        </ol>    
  </section>
 

   <br>
    <br>
    
  
  <div class="container-fluid">
    <div class="col-md-8 col-md-offset-2">
   
     <div class="box">
              <?php 
                    if(isset($success))
              { ?>
              <div class="alert alert-success" style="text-align:center">
                <?php
                  echo $success;
                ?>
               </div>
            <?php
             
              }  
              ?>


              <?php 
                    if(isset($error))
              { ?>
              <div class="alert alert-warning" style="text-align:center">
                <?php
                  echo $error;
                ?>
               </div>
            <?php
             
              }  
              ?>

                <?php 
                    if(isset($error2))
              { ?>
              <div class="alert alert-warning" style="text-align:center">
                <?php
                  echo $error2;
                ?>
               </div>
            <?php
             
              }  
              ?>

                <div class="box box-info">
                    <div class="box-header with-border">
                         <h3 class="box-title">Order Details</h3>
                          <div class="box-tools">
                            <div class="input-group input-group-sm" style="width: 150px;">
                             
                            </div>
                          </div>

          

   


            <div class="box-body">
              <ul class="products-list product-list-in-box">

                  <?php

                     $id='';

                    foreach ($h->result() as $row)

                      {

                        $id=$row->order_id;

                     ?>
                                                         <?php if(!empty($row->order_topic)){ ?>
                                                          <li class="item">
                
                                                            <div class="product-info">
                                                              <a href="javascript:void(0)" class="product-title">Order Title</a>
                                                               <span class="product-description">
                                                                 <?php echo $row->order_topic; ?>
                                                                  </span>
                                                                </div>
                                                              </li>
                                                       <?php } ?>

                                                        <?php if(!empty($row->order_instructions)){ ?>
                                                          <li class="item">
                
                                                            <div class="product-info">
                                                              <a href="javascript:void(0)" class="product-title">Order Title</a>
                                                               <span class="product-description">
                                                                 <?php echo $row->order_instructions; ?>
                                                                  </span>
                                                                </div>
                                                              </li>
                                                       <?php } ?>

                                                        <?php if(!empty($row->order_payeramount)){ ?>
                                                          <li class="item">
                
                                                            <div class="product-info">
                                                              <a href="javascript:void(0)" class="product-title"> Order Amount</a>
                                                               <span class="product-description">
                                                                 <?php echo $row->order_payeramount; ?>
                                                                  </span>
                                                                </div>
                                                              </li>
                                                       <?php } ?>

                                                         <?php if(!empty($row->order_paymentstatus)){ ?>
                                                          <li class="item">
                
                                                            <div class="product-info">
                                                              <a href="javascript:void(0)" class="product-title"> Payment Status</a>
                                                               <span class="product-description">
                                                                 <?php echo $row->order_paymentstatus; ?>
                                                                  </span>
                                                                </div>
                                                              </li>
                                                       <?php } ?>


                                                        <?php if(!empty($row->order_files)){ ?>
                                                            <li class="item">
                
                                                            <div class="product-info">
                                                              <a href="javascript:void(0)" class="product-title">Files</a>
                                                               <span class="product-description">
                                                                <?php
                                                                       if($row->order_files==NULL)
                                                                         {  ?>
                                                                         
                                                                             <td><?php echo 'NO FILES' ; ?></a></td>
                                                                   
                                                                         
                                                                     <?php    } 
                                                                     
                                                                        else
                                                                              {
                                                                              
                                                                              
                                                                                   $category =$row->order_files;
                                                           $pieces = explode(",", $category); 
                                                             $number=count($pieces);
                                                              $direct='/files'; 
                                                        echo  '<td>';
                                                      for($i=0;$i<$number;$i++){
                                                     
                                                                             ?>
                                         
                                                                   <a href="<?php echo base_url($direct)."/".$pieces[$i]; ?>"><?php echo  $pieces[$i] ; ?></a>
                                                                   <br>
                                                                        
                                                                 <?php      
                                                                    }
                                                                    echo '</td>';
                                                                 }
                                                               ?>
                                                                   </span>
                                                                    <br>
                                                                  
                                                                </div>
                                                              </li>
                                                       <?php } ?>


                                                      
                                                            <li class="item">
                
                                                            <div class="product-info">
                                                              <a href="javascript:void(0)" class="product-title">Completed Files</a>
                                                               <span class="product-description">
                                                               <?php  
                                                               $category =$row->order_complete;
                                                               $pieces = explode(",", $category); 
                                                               $number=count($pieces);
                                                                $haha='/complete'; 
                                                                echo  '<td>';
                                                                for($i=0;$i<$number;$i++){
                                                       
                                                                               ?>
                                                                       
                                                                           <a href="<?php echo base_url($haha)."/".$pieces[$i]; ?>"><?php echo  $pieces[$i] ; ?></a>
                                                                           <br>
                                                                                
                                                                         <?php      
                                                                            }
                                                                            echo '</td>';?> 
                                                                   </span>
                                                                    <br>
                                                                  
                                                                </div>
                                                              </li>
                                                      


                                                        <?php if(!empty($row->cust_name)){ ?>
                                                          <li class="item">
                
                                                            <div class="product-info">
                                                              <a href="javascript:void(0)" class="product-title">Customer Name</a>
                                                               <span class="product-description">
                                                                 <?php echo $row->cust_name; ?>
                                                                  </span>
                                                                </div>
                                                              </li>
                                                       <?php } ?>

                                                        <?php if(!empty($row->cust_phone)){ ?>
                                                          <li class="item">
                
                                                            <div class="product-info">
                                                              <a href="javascript:void(0)" class="product-title">Customer Phone</a>
                                                               <span class="product-description">
                                                                 <?php echo $row->cust_phone; ?>
                                                                  </span>
                                                                </div>
                                                              </li>
                                                       <?php } ?>

                                                        <?php if(!empty($row->cust_email)){ ?>
                                                          <li class="item">
                
                                                            <div class="product-info">
                                                              <a href="javascript:void(0)" class="product-title">Customer Email</a>
                                                               <span class="product-description">
                                                                 <?php echo $row->cust_email; ?>
                                                                  </span>
                                                                </div>
                                                              </li>
                                                       <?php } 

                                                       if($row->order_statusid==5){ ?>
                                                        <h5><b>Send Order to client</b></h5>

                                                          <form method="post"  enctype="multipart/form-data" action="<?php echo base_url('admin/send')?>">       
                                                        <td><input name="userfile[]"  id="userfile" type="file"></td>  
                                                                               
                                                         <input type="hidden" value="<?php echo $row->cust_email; ?>" name="email">    
                                                         
                                                         <input type="hidden" value="<?php echo $row->order_id; ?>" name="order_id">    
                                                        <td> <br><button type="submit" class="btn btn-success">Send</button> </td>   
                                                          </form>  







                                                       <?php }

                                                       }
                                                       ?>

                                                       

                                                      
                                                         
                                                        

                          

                                                   


                                                     


                                                   

              </ul>
            </div>

         

                             <!--   <div class="row">

                                  <div class="col-md-8 mar-btm">

                                    <label class="control-label">Interstitial Upload (IMAGE SIZE:250*250) </label>

                                      <input type="file" name="inter" required>

                                  </div>

                                  

                              </div>
 -->



                               

                             

                          </div>

                       

                         
                    

                      <!--===================================================-->

                      <!--End No Label Form-->

          

                  </div>

              </div>

          </div>

         </div>

  
     </div>
<style type="text/css">
  
  .modal-dialog {
  
  overflow-x: auto;
  overflow-y: auto;
}

@media (min-width: 768px) .modal-dialog {
  margin: 0px auto;
}


</style>



        



        <!-- FOOTER -->

        <!--===================================================-->

       <?php include 'admin_footer.php'; ?>

