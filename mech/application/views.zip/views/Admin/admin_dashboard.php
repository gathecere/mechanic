<?php include 'admin_header.php'; ?>


<div class="content-wrapper">
<section class="content-header">
      <h1>
        Dashboard
        <small>Version 2.0</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>
  <section class="content">

  <div class="row">
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="fa fa-clock-o"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Pending Orders</span>
              <span class="info-box-number"> <?php if(isset($pending)){ echo $pending;} ?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-red"><i class="fa fa-clone"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Current Orders</span>
              <span class="info-box-number"><?php if(isset($current)){ echo $current;} ?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->

        <!-- fix for small devices only -->
        <div class="clearfix visible-sm-block"></div>

        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-green"><i class="fa fa-dot-circle-o"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Complete Orders</span>
              <span class="info-box-number"><?php if(isset($complete)){ echo $complete;} ?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>

         <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-orange"><i class="fa fa-money"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Earned All Time ($)</span>
              <span class="info-box-number"><?php if(isset($earned)){ echo $earned;} ?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>

        



    <hr>

        <!--===================================================-->

    


             <div class="col-md-12 col-sm-8">


      
             

                <div class="col-md-12">

                 
                  <div class="panel">

                  <div class="panel-heading">

                                          <h3 class="panel-title">10 Latest Orders</h3>

                                      </div>

                      <div class="panel-body">

                                          <div class="table-responsive">

                                                <table class="table table-hover table-striped" id="mpesa_repayments">
                                              <thead>
                                                <tr>
                                                  <th>ORDER ID</th>
                                                                  <th>Payment Status</th>
                                                                  <th>Amount in $</th>
                                                                   
                                                                  <th>Order Topic</th>
                                                                  <th>Order Instructions</th>
                                                                  <th>Files</th>
                                                                  <th>Cust Name</th>
                                                                   <th>Cust Phone</th>
                                                                   <th>Cust Email</th>
                                                                   <th>Action</th>
                                                </tr>
                                              </thead>
                                              <tbody>
                                                 <?php  
                                                  
                                                    
                                                       foreach ($h->result() as $row) 
                              {
                                                                                             
                                                                                                  
                                                                                               
                                                                                      
                                            ?>
                                                            
                                                  <tr>
                                                  
                                                                       <td><?php echo $row->order_id; ?></td>
                                                                       <td><?php echo $row->order_paymentstatus; ?></td>
                                                                       <td><?php echo $row->order_payeramount; ?></td>
                                                                        <td><?php echo $row->order_topic; ?></td>
                                                                         <td><?php echo $row->order_instructions; ?></td>
                                                                         
                                                                         <?php
                                                                           if($row->order_files==NULL)
                                                                           {  ?>
                                                                           
                                                                               <td><?php echo 'NO FILES' ; ?></a></td>
                                                                     
                                                                           
                                                                       <?php    } 
                                                                       
                                                                          else
                                                                                {
                                                                                
                                                                                
                                                                                     $category =$row->order_files;
                                                             $pieces = explode(",", $category); 
                                                               $number=count($pieces);
                                                                $direct='/files'; 
                                                          echo  '<td>';
                                                        for($i=0;$i<$number;$i++){
                                                       
                                                                               ?>
                                                                       
                                                                           <a href="<?php echo base_url($direct)."/".$pieces[$i]; ?>"><?php echo  $pieces[$i] ; ?></a>
                                                                           <br>
                                                                                
                                                                         <?php      
                                                                            }
                                                                            echo '</td>';
                                                                         }
                                                                       ?>
                                                                       
                                                                      <td><?php echo $row->cust_name; ?></td>  
                                                                        <td><?php echo $row->cust_phone; ?></td>
                                                                        <td><?php echo $row->cust_email; ?></td>  
                                                                        <td> <a href="  <?php  echo site_url("admin/update/$row->order_id"); ?>"><button type="button" class="btn btn-success">Approve</button></a> </td>
                                                        
                                                                     
                                                                       
                                                              </tr>
                                                       
                                                    <?php } ?>
                                              </tbody>
                                            </table>

                                          </div>

                                      </div>

                      <!--===================================================-->

                      <!--End No Label Form-->

          

                  </div>

              </div>

     


             


      

            

                         

          

                      

            






                    </div>

                  </div>

                </div>
            

             
         

            <!--===================================================-->

            <!--END MAIN NAVIGATION-->



       


        



        <!-- FOOTER -->

        <!--===================================================-->

       <?php include 'admin_footer.php'; ?>

     