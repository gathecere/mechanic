<?php include 'admin_header.php' ?>

<div class="page-intro">

				<div class="container">

					<div class="row">

						<div class="col-md-12">

							<ol class="breadcrumb">

								<li>Welcome Admin</li>

								

							</ol>

						</div>

					</div>

				</div>

			</div>

			<div class="container" style="margin-top: 20px;">

					<div class="row">

						<div class="col-md-10 col-md-offset-1">
				 <?php
				  if(isset($success))
				  {
				  	?>
				  	  <div class="alert alert-success">
				  	  <?php
				  	     echo $success;

				  	  ?>
				  	  </div>

				  	<?php

				  }

				 ?>

			     <div class="table-responsive">

                   <table class="table table-striped" style="font-size: 12px;">

								<thead>

									 <tr>

                                    

                                    <th>ID</th>

                                    <th>Paper Title</th>

                                    

                                     

                                    <th>Action</th>

                                  
                                    

                                   

                                   

                                    

                                </tr>

								</thead>

								<tbody>

									 	<?php 

							

                                                        

                                                         foreach ($del->result() as $row) 

                           {                                

							?>

                              

										<tr>

										
 
                                         <td><?php echo $row->previous_id; ?></td>

                                            <td><?php echo $row->previous_title; ?></td>

                                       

                                         <td><a href='<?php echo base_url("Admin/delete_entry/$row->previous_id");  ?>'' Onclick="return confirm('Are you sure you want to delete this record?')" >Delete</a></td>

                                       

                                           

                                         
                                         

                                </tr>

                         

						          <?php } ?>

								</tbody>

							</table>

						  </div>

						

					</div>

				</div>

			</div>



<?php include 'admin_footer.php'

 ?>