


 <aside class="main-sidebar">
            <!-- sidebar: style can be found in sidebar.less -->
            <section class="sidebar">   
                <div class="user-panel">
                  <div class="pull-left image">
                    <i class="fa fa-user-circle-o fa-3x" style="color: white;"></i>
                  </div>
                  <div class="pull-left info">
                    <p>Hi Henry</p>
                    <a href="#"><i class="fa fa-circle text-success" ></i> Online</a>
                  </div>
                </div>            
                <!-- Sidebar Menu -->
                <ul class="sidebar-menu" data-widget="tree">
                  <li class="<?php if($this->uri->segment(2)=="admin_dashboard"){echo "active";}?>"> <a href="<?php echo base_url('admin/admin_dashboard')?>"><i class="fa fa-th"></i> <span>Dashboard</span> <span class="label label-important"></span></a>
                    </li>
               
                  <li class="<?php if($this->uri->segment(2)=="pending" OR $this->uri->segment(2)=="get_ad_details"){echo "active";}?>"> <a href="<?php echo base_url('admin/pending')?>"><i class="fa fa-clock-o"></i> <span>Pending Orders</span> <span class="label label-important"></span></a>
                    </li>

                    <li class="<?php if($this->uri->segment(2)=="get_current" OR $this->uri->segment(2)=="get_ad_details"){echo "active";}?>"> <a href="<?php echo base_url('admin/get_current')?>"><i class="fa fa-clone"></i> <span>Current Orders</span> <span class="label label-important"></span></a>
                    </li>

                      <li class="<?php if($this->uri->segment(2)=="get_complete" OR $this->uri->segment(2)=="get_ad_details"){echo "active";}?>"> <a href="<?php echo base_url('admin/get_complete')?>"><i class="fa fa-dot-circle-o"></i> <span>Completed Orders</span> <span class="label label-important"></span></a>
                    </li>

                      <li class="<?php if($this->uri->segment(2)=="get_orders_now" OR $this->uri->segment(2)=="get_ad_details"){echo "active";}?>"> <a href="<?php echo base_url('admin/get_orders_now')?>"><i class="fa fa-dot-circle-o"></i> <span>Manage Orders</span> <span class="label label-important"></span></a>
                    </li>

                    <!--   <li class="<?php// if($this->uri->segment(2)=="add_previous" OR $this->uri->segment(2)=="add_previous_process"){echo "active";}?>"> <a href="<?php //echo base_url('admin/add_previous')?>"><i class="fa fa-plus"></i> <span>Add Previous Papers</span> <span class="label label-important"></span></a>
                    </li>

                     <li class="<?php //if($this->uri->segment(2)=="add_sample" OR $this->uri->segment(2)=="add_sample_process"){echo "active";}?>"> <a href="<?php//echo base_url('admin/add_sample')?>"><i class="fa fa-plus"></i> <span>Add Samples</span> <span class="label label-important"></span></a>
                    </li> -->

                  <li class="treeview <?php if($this->uri->segment(2)=="add_previous" or $this->uri->segment(2)=="get_previous_papers" or $this->uri->segment(2)=="registration_fees" ){echo "active menu-open";}?>">
                      <a href="#"><i class="fa fa-sticky-note-o"></i> <span>Previous Papers</span><span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span></a>
                        <ul class="treeview-menu">
                          <li class="<?php if($this->uri->segment(2)=="add_previous"){echo "active";}?>"> <a href="<?php echo base_url('admin/add_previous')?>"><i class="fa fa-plus"></i> <span>Add Previous Papers</span> <span class="label label-important"></span></a></li>
                          <li class="<?php if($this->uri->segment(2)=="rejected"){echo "active";}?>"> <a href="<?php echo base_url('admin/get_previous_papers')?>"><i class="fa fa-rotate-right"></i> <span>Manage Previous Papers</span> <span class="label label-important"></span></a></li>
                          
                        
                      </ul>
                  </li>


                  <li class="treeview <?php if($this->uri->segment(2)=="add_sample" or $this->uri->segment(2)=="cancelled" or $this->uri->segment(2)=="registration_fees" ){echo "active menu-open";}?>">
                      <a href="#"><i class="fa fa-file-pdf-o"></i> <span>Samples</span><span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span></a>
                        <ul class="treeview-menu">
                          <li class="<?php if($this->uri->segment(2)=="add_sample"){echo "active";}?>"> <a href="<?php echo base_url('admin/add_sample')?>"><i class="fa fa-plus"></i> <span>Add Samples</span> <span class="label label-important"></span></a></li>
                          <li class="<?php if($this->uri->segment(2)=="rejected"){echo "active";}?>"> <a href="<?php echo base_url('admin/get_samples')?>"><i class="fa fa-rotate-right"></i> <span>Manage Samples</span> <span class="label label-important"></span></a></li>
                          
                        
                      </ul>
                  </li>


             
                 
              
                    
                </ul>
                <!-- /.sidebar-menu -->
            </section>
            <!-- /.sidebar -->
        </aside>