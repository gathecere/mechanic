<div class="container" >

          <div class="row" style="background: #4DBD33; color:white">

            <div class="col-md-8 col-md-offset-2">

              <div class="call-to-action">

                <h1 class="title" style="color: white; font-size: 25px;">We have made it easy for you to place an order</h1>

                <p>
                 SEND YOUR ORDER DETAILS TO:
                 <p>
                 WHATSAPP: +1 (209) 260-9257
                 <p>
                 TWITTER: <a style="color:white" href="https://twitter.com/writerscorp">Our Twitter Page</a>
               
                 <p>
                 EMAIL:info@writers-corp.net


              



                </p>

             



                <!-- Modal -->

               

              

              

              </div>

            </div>

          </div>

        </div>



<footer id="footer">



        <!-- .footer start -->

        <!-- ================ -->

        <div class="footer">

          <div class="container">

            <div class="row">

              <div class="col-md-9">

                <div class="footer-content">

                  <div class="logo-footer"><img id="logo-footer" src="<?php echo base_url('images/writerscorpwhitelogo.png'); ?>" alt=""></div>

                  <div class="row">

                    <div class="col-md-6">

                      <p>We are social, connect with us on social media for fruitful engagements.</p>

                      <ul class="social-links circle">

                        <li class="facebook"><a target="_blank" href="http://www.facebook.com/"><i class="fa fa-facebook"></i></a></li>

                        <li class="twitter"><a target="_blank" href="http://www.twitter.com/"><i class="fa fa-twitter"></i></a></li>

                        <li class="googleplus"><a target="_blank" href="http://plus.google.com/"><i class="fa fa-google-plus"></i></a></li>

                        <li class="skype"><a target="_blank" href="http://www.skype.com/"><i class="fa fa-skype"></i></a></li>

                        <li class="linkedin"><a target="_blank" href="http://www.linkedin.com/"><i class="fa fa-linkedin"></i></a></li>

                      </ul>

                    </div>

                    <div class="col-md-3">



                      <ul class="list-icons">

                        <li><i class="fa fa-arrow-right"></i><a style="color: white;" href="<?php echo base_url('professionalwriting/privacy'); ?>"> Privacy & Cookie Policy</a></li>

                      <!--   <li><i class="fa fa-arrow-right"></i> Cookie Policy</li> -->

                       

                      </ul>

                    </div>

                  </div>

                  

                </div>

              </div>

              <div class="space-bottom hidden-lg hidden-xs"></div>

              <div class="col-sm-6 col-md-3">

                <div class="footer-content">

                  <h2>We Accept</h2>

                  <nav>

                    <ul class="nav nav-pills nav-stacked">

                      <li><a href="<?php echo base_url('professionalwriting/paypal_payments'); ?>">PayPal</a></li>

                      <li class="active"><a href="#">Visa</a></li>

                      <li><a href="#">Mastercard</a></li>

                     

                    </ul>

                  </nav>

                </div>

              </div>

       

            </div>

            <div class="space-bottom hidden-lg hidden-xs"></div>

          </div>

        </div>

        <!-- .footer end -->



        <!-- .subfooter start -->

        <!-- ================ -->

        <div class="subfooter">

         <div class="kevvy">

          <div class="container">

            <div class="row">

              <div class="col-md-6">

                <p>Copyright © 2020 Writers Corp. All Rights Reserved. Designed by <a target="_blank" href="http://qserve.co.ke/">Qserve</a></p>

              </div>

              <div class="col-md-6">

                <nav class="navbar navbar-default" role="navigation">

                  <!-- Toggle get grouped for better mobile display -->

                  <div class="navbar-header">

                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse-2">

                      <span class="sr-only">Toggle navigation</span>

                      <span class="icon-bar"></span>

                      <span class="icon-bar"></span>

                      <span class="icon-bar"></span>

                    </button>

                  </div>   

                  <div class="collapse navbar-collapse" id="navbar-collapse-2">

                    <ul class="nav navbar-nav">

                      <li class="<?php if($this->uri->segment(2)=='index' || $this->uri->segment(2)==null ){ echo 'active'; }; ?>">

                            <a href="<?php echo base_url(); ?>" class="" >Home</a>

                            

                          </li>

                          <li class="<?php if($this->uri->segment(2)=='pricing'){ echo 'active'; }; ?>">

                            <a href="<?php echo base_url('professionalwriting/pricing'); ?>" >Pricing</a>

                           

                               

                          </li>



                          <li class="<?php if($this->uri->segment(2)=='ordernow'){ echo 'active'; }; ?>">

                            <a href="<?php echo base_url('professionalwriting/order_now'); ?>" >Order Now</a>

                           

                               

                          </li>



                          <li class="<?php if($this->uri->segment(2)=='our_writers'){ echo 'active'; }; ?>">

                            <a href="<?php echo base_url('professionalwriting/our_writers'); ?>" >Our Writers</a>

                           

                               

                          </li>



                          <li class="<?php if($this->uri->segment(2)=='samples'){ echo 'active'; }; ?>">

                            <a href="<?php echo base_url('professionalwriting/samples'); ?>" >Samples</a>

                           

                               

                          </li>



                          <li class="<?php if($this->uri->segment(2)=='contactus'){ echo 'active'; }; ?>">

                            <a href="<?php echo base_url('professionalwriting/contactus'); ?>" >Contact Us</a>

                           

                               

                          </li>

                    </ul>

                  </div>

                </nav>

              </div>

            </div>

          </div>

        </div>

      </div>

        <!-- .subfooter end -->



      </footer>

      <!-- footer end -->



    </div>

    <!-- page-wrapper end -->



    <!-- JavaScript files placed at the end of the document so the pages load faster

    ================================================== -->

    <!-- Jquery and Bootstap core js files -->

    

    <script type="text/javascript" src="<?php echo base_url('bootstrap/js/bootstrap.min.js') ?>"></script>



    <script type="text/javascript" src="<?php echo base_url('assets/js/bootstrap-formhelpers.min.js') ?>"></script>



    <!-- Modernizr javascript -->

    <script type="text/javascript" src="<?php echo base_url('plugins/modernizr.js') ?>"></script>



    <!-- jQuery REVOLUTION Slider  -->

    <script type="text/javascript" src="<?php echo base_url('plugins/rs-plugin/js/jquery.themepunch.tools.min.js') ?>"></script>

    <script type="text/javascript" src="<?php echo base_url('plugins/rs-plugin/js/jquery.themepunch.revolution.min.js') ?>"></script>



    

    <!-- Isotope javascript -->

    <script type="text/javascript" src="<?php echo base_url('plugins/isotope/isotope.pkgd.min.js') ?>"></script>



    <!-- Owl carousel javascript -->

    <script type="text/javascript" src="<?php echo base_url('plugins/owl-carousel/owl.carousel.js') ?>"></script>



    <!-- Magnific Popup javascript -->

    <script type="text/javascript" src="<?php echo base_url('plugins/magnific-popup/jquery.magnific-popup.min.js') ?>"></script>



    <!-- Appear javascript -->

    <script type="text/javascript" src="<?php echo base_url('plugins/jquery.appear.js') ?>"></script>



    <!-- Count To javascript -->

    <script type="text/javascript" src="<?php echo base_url('plugins/jquery.countTo.js') ?>"></script>



    <!-- Parallax javascript -->

    <script src="<?php echo base_url('plugins/jquery.parallax-1.1.3.js') ?>"></script>



    <!-- Contact form -->

   <!--  <script src="<?php //echo base_url('plugins/jquery.validate.js') ?>"></script> -->



    <!-- SmoothScroll javascript -->

    <script type="text/javascript" src="<?php echo base_url('plugins/jquery.browser.js') ?>"></script>

    <script type="text/javascript" src="<?php echo base_url('plugins/SmoothScroll.js') ?>"></script>



    <!-- Initialization of Plugins -->

    <script type="text/javascript" src="<?php echo base_url('js/template.js') ?>"></script>



    <!-- Custom Scripts -->

    <script type="text/javascript" src="<?php echo base_url('js/custom.js') ?>"></script>

    <!-- Color Switcher (Remove these lines) -->

   

   

    <!-- Color Switcher End -->














        

  



  </body>





</html>

