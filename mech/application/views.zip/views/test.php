<?php

$main_array=array(); //declare an array

//loop through results

$namely=>array(
              //add all params
              'id' => $row['id'], 
              'match_time' => $row['match_time'], 

              );
















		  