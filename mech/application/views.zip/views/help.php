<?php
include('header.php');
?> 
 <section id="values" class="" style="background-color: #f5f7fa; min-height: 200px; padding-top: 20px;">
 <div class="container" >

    <div class="row">
 At Betstadia.com, our client is our priority. For new customers, click <a href="<?php echo base_url('betting/subscribe');?>"> here</a> to subscribe. Need help drop as an email (top of website) or SMS your issue to +254000000. You could also call us between 8.00 a.m to 8.00 p.m DAILY.
 You can reset your password here:
 <br>
  <a href="<?php echo base_url('betting/reset_password');?>" class="btn btn-large btn-orange">Reset Password</a>

 </div>
</div>
 </section>

      <?php
include('footer.php');
?>