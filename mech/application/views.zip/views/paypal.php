<?php include 'header.php' ?>

<div class="page-intro">
        <div class="container">
          <div class="row">
            <div class="col-md-12">
              <ol class="breadcrumb">
                <li><i class="fa fa-home pr-10"></i><a href="<?php echo base_url(); ?>">Home</a></li>
                <li class="active">Success</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
      <!-- page-intro end -->

      <!-- main-container start -->
      <!-- ================ -->
      <section class="main-container">

        <div class="container">
          <div class="row">

            <!-- main start -->
            <!-- ================ -->
            <div class="main col-md-12">

              <!-- page-title start -->
              <!-- ================ -->
              
              <!-- page-title end -->
              
              <div class="row">
               
                <div class="col-md-5 col-md-offset-3">
                 <div class="login-wrapper">
                       <h2 class="page-title" style="text-align: center; position: relative; bottom: 15px;">PayPal Payments</h2>

                       <h5>Dear Client,</h5>
  
                      <p>You can make direct payments to our Paypal email:payments@writers-corp.net</p>
                     
                                               
                       
                        
                      
                 
                                   
              
                  
                  
                </div>
               </div>
                <!-- sidebar start -->
               
                <!-- sidebar end -->
              </div>
              <hr>
            </div>
            <!-- main end -->

          </div>
        </div>
      </section>


<?php include 'footer.php' ?>
